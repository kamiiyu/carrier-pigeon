--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.1
-- Dumped by pg_dump version 9.6.1

-- Started on 2017-01-09 08:01:43 CST

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS fk_rails_f29bf9cdf2;
ALTER TABLE IF EXISTS ONLY public.enrollments DROP CONSTRAINT IF EXISTS fk_rails_e860e0e46b;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS fk_rails_d1c86232a5;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS fk_rails_b590639e90;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS fk_rails_b2bbf87303;
ALTER TABLE IF EXISTS ONLY public.enrollments DROP CONSTRAINT IF EXISTS fk_rails_a6378ee767;
ALTER TABLE IF EXISTS ONLY public.departments_events DROP CONSTRAINT IF EXISTS fk_rails_a52209262f;
ALTER TABLE IF EXISTS ONLY public.departments_events DROP CONSTRAINT IF EXISTS fk_rails_1fde746960;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS fk_rails_0cb5590091;
DROP INDEX IF EXISTS public.index_users_on_team_id;
DROP INDEX IF EXISTS public.index_users_on_reset_password_token;
DROP INDEX IF EXISTS public.index_users_on_manager_id;
DROP INDEX IF EXISTS public.index_users_on_job_title_id;
DROP INDEX IF EXISTS public.index_users_on_employment_type_id;
DROP INDEX IF EXISTS public.index_users_on_email;
DROP INDEX IF EXISTS public.index_users_on_department_id;
DROP INDEX IF EXISTS public.index_teams_on_leader_id;
DROP INDEX IF EXISTS public.index_events_on_user_id;
DROP INDEX IF EXISTS public.index_events_on_event_type;
DROP INDEX IF EXISTS public.index_enrollments_on_user_id;
DROP INDEX IF EXISTS public.index_enrollments_on_event_id;
DROP INDEX IF EXISTS public.index_departments_on_manager_id;
DROP INDEX IF EXISTS public.index_departments_events_on_event_id;
DROP INDEX IF EXISTS public.index_departments_events_on_department_id;
DROP INDEX IF EXISTS public.index_ckeditor_assets_on_type;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.teams DROP CONSTRAINT IF EXISTS teams_pkey;
ALTER TABLE IF EXISTS ONLY public.schema_migrations DROP CONSTRAINT IF EXISTS schema_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public.job_titles DROP CONSTRAINT IF EXISTS job_titles_pkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_pkey;
ALTER TABLE IF EXISTS ONLY public.enrollments DROP CONSTRAINT IF EXISTS enrollments_pkey;
ALTER TABLE IF EXISTS ONLY public.employment_types DROP CONSTRAINT IF EXISTS employment_types_pkey;
ALTER TABLE IF EXISTS ONLY public.departments DROP CONSTRAINT IF EXISTS departments_pkey;
ALTER TABLE IF EXISTS ONLY public.departments_events DROP CONSTRAINT IF EXISTS departments_events_pkey;
ALTER TABLE IF EXISTS ONLY public.ckeditor_assets DROP CONSTRAINT IF EXISTS ckeditor_assets_pkey;
ALTER TABLE IF EXISTS ONLY public.ar_internal_metadata DROP CONSTRAINT IF EXISTS ar_internal_metadata_pkey;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.teams ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.job_titles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.enrollments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.employment_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.departments_events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.departments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ckeditor_assets ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.teams_id_seq;
DROP TABLE IF EXISTS public.teams;
DROP TABLE IF EXISTS public.schema_migrations;
DROP SEQUENCE IF EXISTS public.job_titles_id_seq;
DROP TABLE IF EXISTS public.job_titles;
DROP SEQUENCE IF EXISTS public.events_id_seq;
DROP TABLE IF EXISTS public.events;
DROP SEQUENCE IF EXISTS public.enrollments_id_seq;
DROP TABLE IF EXISTS public.enrollments;
DROP SEQUENCE IF EXISTS public.employment_types_id_seq;
DROP TABLE IF EXISTS public.employment_types;
DROP SEQUENCE IF EXISTS public.departments_id_seq;
DROP SEQUENCE IF EXISTS public.departments_events_id_seq;
DROP TABLE IF EXISTS public.departments_events;
DROP TABLE IF EXISTS public.departments;
DROP SEQUENCE IF EXISTS public.ckeditor_assets_id_seq;
DROP TABLE IF EXISTS public.ckeditor_assets;
DROP TABLE IF EXISTS public.ar_internal_metadata;
DROP EXTENSION IF EXISTS plpgsql;
DROP SCHEMA IF EXISTS public;
--
-- TOC entry 3 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- TOC entry 2545 (class 0 OID 0)
-- Dependencies: 3
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- TOC entry 1 (class 3079 OID 12655)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2546 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 196 (class 1259 OID 16488)
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 202 (class 1259 OID 16543)
-- Name: ckeditor_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE ckeditor_assets (
    id integer NOT NULL,
    data_file_name character varying NOT NULL,
    data_content_type character varying,
    data_file_size integer,
    data_fingerprint character varying,
    type character varying(30),
    width integer,
    height integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 201 (class 1259 OID 16541)
-- Name: ckeditor_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE ckeditor_assets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2547 (class 0 OID 0)
-- Dependencies: 201
-- Name: ckeditor_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE ckeditor_assets_id_seq OWNED BY ckeditor_assets.id;


--
-- TOC entry 185 (class 1259 OID 16386)
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE departments (
    id integer NOT NULL,
    name character varying,
    manager_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    is_active boolean DEFAULT true NOT NULL
);


--
-- TOC entry 204 (class 1259 OID 16555)
-- Name: departments_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE departments_events (
    id integer NOT NULL,
    department_id integer,
    event_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 203 (class 1259 OID 16553)
-- Name: departments_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE departments_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2548 (class 0 OID 0)
-- Dependencies: 203
-- Name: departments_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE departments_events_id_seq OWNED BY departments_events.id;


--
-- TOC entry 186 (class 1259 OID 16393)
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE departments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2549 (class 0 OID 0)
-- Dependencies: 186
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE departments_id_seq OWNED BY departments.id;


--
-- TOC entry 187 (class 1259 OID 16395)
-- Name: employment_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE employment_types (
    id integer NOT NULL,
    name character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 188 (class 1259 OID 16401)
-- Name: employment_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE employment_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2550 (class 0 OID 0)
-- Dependencies: 188
-- Name: employment_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE employment_types_id_seq OWNED BY employment_types.id;


--
-- TOC entry 200 (class 1259 OID 16519)
-- Name: enrollments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE enrollments (
    id integer NOT NULL,
    event_id integer,
    user_id integer,
    attended boolean DEFAULT false,
    feedback text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 199 (class 1259 OID 16517)
-- Name: enrollments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE enrollments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2551 (class 0 OID 0)
-- Dependencies: 199
-- Name: enrollments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE enrollments_id_seq OWNED BY enrollments.id;


--
-- TOC entry 198 (class 1259 OID 16498)
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE events (
    id integer NOT NULL,
    name character varying,
    event_type character varying,
    description text,
    organizer character varying DEFAULT 'XO Group'::character varying,
    started_at date,
    ended_at date,
    enroll_started_at date,
    enroll_ended_at date,
    capacity integer DEFAULT '-1'::integer,
    public boolean DEFAULT true,
    remarks text,
    user_id integer,
    status character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 197 (class 1259 OID 16496)
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2552 (class 0 OID 0)
-- Dependencies: 197
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE events_id_seq OWNED BY events.id;


--
-- TOC entry 189 (class 1259 OID 16403)
-- Name: job_titles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE job_titles (
    id integer NOT NULL,
    name character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    is_active boolean DEFAULT true NOT NULL
);


--
-- TOC entry 190 (class 1259 OID 16410)
-- Name: job_titles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE job_titles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2553 (class 0 OID 0)
-- Dependencies: 190
-- Name: job_titles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE job_titles_id_seq OWNED BY job_titles.id;


--
-- TOC entry 195 (class 1259 OID 16480)
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE schema_migrations (
    version character varying NOT NULL
);


--
-- TOC entry 191 (class 1259 OID 16412)
-- Name: teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE teams (
    id integer NOT NULL,
    name character varying,
    leader_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    is_active boolean DEFAULT true NOT NULL
);


--
-- TOC entry 192 (class 1259 OID 16419)
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE teams_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2554 (class 0 OID 0)
-- Dependencies: 192
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE teams_id_seq OWNED BY teams.id;


--
-- TOC entry 193 (class 1259 OID 16421)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE users (
    id integer NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    sign_in_count integer DEFAULT 0 NOT NULL,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip inet,
    last_sign_in_ip inet,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    first_name character varying NOT NULL,
    last_name character varying NOT NULL,
    chinese_name character varying NOT NULL,
    gender integer NOT NULL,
    on_board_at date,
    birthday_month integer,
    department_id integer,
    job_title_id integer,
    team_id integer,
    tokens json,
    provider character varying DEFAULT 'email'::character varying,
    uid character varying DEFAULT ''::character varying,
    on_resigned_at date,
    status integer DEFAULT 1 NOT NULL,
    id_card character varying,
    role character varying DEFAULT 'User'::character varying NOT NULL,
    manager_id integer,
    employment_type_id integer,
    contract_end_date date
);


--
-- TOC entry 194 (class 1259 OID 16434)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2555 (class 0 OID 0)
-- Dependencies: 194
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- TOC entry 2354 (class 2604 OID 16546)
-- Name: ckeditor_assets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY ckeditor_assets ALTER COLUMN id SET DEFAULT nextval('ckeditor_assets_id_seq'::regclass);


--
-- TOC entry 2334 (class 2604 OID 16436)
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY departments ALTER COLUMN id SET DEFAULT nextval('departments_id_seq'::regclass);


--
-- TOC entry 2355 (class 2604 OID 16558)
-- Name: departments_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY departments_events ALTER COLUMN id SET DEFAULT nextval('departments_events_id_seq'::regclass);


--
-- TOC entry 2335 (class 2604 OID 16437)
-- Name: employment_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY employment_types ALTER COLUMN id SET DEFAULT nextval('employment_types_id_seq'::regclass);


--
-- TOC entry 2352 (class 2604 OID 16522)
-- Name: enrollments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY enrollments ALTER COLUMN id SET DEFAULT nextval('enrollments_id_seq'::regclass);


--
-- TOC entry 2348 (class 2604 OID 16501)
-- Name: events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY events ALTER COLUMN id SET DEFAULT nextval('events_id_seq'::regclass);


--
-- TOC entry 2337 (class 2604 OID 16438)
-- Name: job_titles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY job_titles ALTER COLUMN id SET DEFAULT nextval('job_titles_id_seq'::regclass);


--
-- TOC entry 2339 (class 2604 OID 16439)
-- Name: teams id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY teams ALTER COLUMN id SET DEFAULT nextval('teams_id_seq'::regclass);


--
-- TOC entry 2347 (class 2604 OID 16440)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- TOC entry 2531 (class 0 OID 16488)
-- Dependencies: 196
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	development	2017-01-06 17:18:28.583119	2017-01-06 17:18:28.583119
\.


--
-- TOC entry 2537 (class 0 OID 16543)
-- Dependencies: 202
-- Data for Name: ckeditor_assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY ckeditor_assets (id, data_file_name, data_content_type, data_file_size, data_fingerprint, type, width, height, created_at, updated_at) FROM stdin;
1	image1.png	image/png	390992	8e681a12cdb7c925139203e5152b6134	Ckeditor::Picture	641	324	2017-01-07 01:25:00.928147	2017-01-07 01:25:00.928147
2	image2.png	image/png	316361	03c2c938b4f2d96302f1eebfbd517db8	Ckeditor::Picture	460	283	2017-01-07 01:25:26.039731	2017-01-07 01:25:26.039731
3	image3.png	image/png	365404	0a319da9cbd75c34f61660040366bcfc	Ckeditor::Picture	474	278	2017-01-07 01:25:43.229459	2017-01-07 01:25:43.229459
4	image4.png	image/png	428876	7c01ff612d60874c34650266c32c39cc	Ckeditor::Picture	516	419	2017-01-07 01:26:19.067138	2017-01-07 01:26:19.067138
5	image5.png	image/png	810070	395d03a46bb1e580e0a12f7fca9a3024	Ckeditor::Picture	719	459	2017-01-07 01:26:35.502687	2017-01-07 01:26:35.502687
6	.xlsx	application/octet-stream	492021	481abf376ef61aac9a02f1d2a040e4d4	Ckeditor::AttachmentFile	\N	\N	2017-01-08 07:26:32.287194	2017-01-08 07:26:32.287194
7	.xlsx	application/octet-stream	492021	481abf376ef61aac9a02f1d2a040e4d4	Ckeditor::AttachmentFile	\N	\N	2017-01-08 07:31:06.89811	2017-01-08 07:31:06.89811
8	canteen.xlsx	application/octet-stream	492021	481abf376ef61aac9a02f1d2a040e4d4	Ckeditor::AttachmentFile	\N	\N	2017-01-08 07:34:22.119536	2017-01-08 07:34:22.119536
9	.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	17357	b35acb31310896954b8d14a8b8f372eb	Ckeditor::AttachmentFile	\N	\N	2017-01-08 07:51:05.250922	2017-01-08 07:51:05.250922
10	温泉注意事项.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	17357	b35acb31310896954b8d14a8b8f372eb	Ckeditor::AttachmentFile	\N	\N	2017-01-08 07:57:51.390864	2017-01-08 07:57:51.390864
11	image.png	image/png	458410	21f5816f18136817c99a95607a053d25	Ckeditor::Picture	1021	770	2017-01-08 08:03:36.879784	2017-01-08 08:03:36.879784
\.


--
-- TOC entry 2556 (class 0 OID 0)
-- Dependencies: 201
-- Name: ckeditor_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('ckeditor_assets_id_seq', 11, true);


--
-- TOC entry 2520 (class 0 OID 16386)
-- Dependencies: 185
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY departments (id, name, manager_id, created_at, updated_at, is_active) FROM stdin;
1	Dev	\N	2016-12-09 12:18:20.171273	2016-12-09 12:18:20.171273	t
2	IT	\N	2016-12-09 12:18:20.175676	2016-12-09 12:18:20.175676	t
3	Admin	\N	2016-12-09 12:18:20.179209	2016-12-09 12:18:20.179209	t
4	QA	\N	2016-12-09 12:18:20.182687	2016-12-09 12:18:20.182687	t
5	National Sales Operation	\N	2016-12-09 12:18:20.18618	2016-12-09 12:18:20.18618	t
6	PMO	\N	2016-12-09 12:18:20.189699	2016-12-09 12:18:20.189699	t
7	DEV	\N	2016-12-09 12:18:20.193137	2016-12-09 12:18:20.193137	t
8	Management	\N	2016-12-09 12:18:20.196691	2016-12-09 12:18:20.196691	t
\.


--
-- TOC entry 2539 (class 0 OID 16555)
-- Dependencies: 204
-- Data for Name: departments_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY departments_events (id, department_id, event_id, created_at, updated_at) FROM stdin;
1	7	1	2017-01-06 17:32:32.874586	2017-01-06 17:32:32.874586
2	1	2	2017-01-06 17:34:54.043701	2017-01-06 17:34:54.043701
3	1	3	2017-01-06 18:54:33.527745	2017-01-06 18:54:33.527745
4	2	3	2017-01-06 18:54:33.529426	2017-01-06 18:54:33.529426
5	3	3	2017-01-06 18:54:33.530749	2017-01-06 18:54:33.530749
6	4	3	2017-01-06 18:54:33.532038	2017-01-06 18:54:33.532038
7	5	3	2017-01-06 18:54:33.533322	2017-01-06 18:54:33.533322
8	6	3	2017-01-06 18:54:33.534431	2017-01-06 18:54:33.534431
9	7	3	2017-01-06 18:54:33.535375	2017-01-06 18:54:33.535375
10	8	3	2017-01-06 18:54:33.536202	2017-01-06 18:54:33.536202
11	1	4	2017-01-08 07:27:22.281442	2017-01-08 07:27:22.281442
12	2	4	2017-01-08 07:27:22.284132	2017-01-08 07:27:22.284132
13	3	4	2017-01-08 07:27:22.28543	2017-01-08 07:27:22.28543
14	4	4	2017-01-08 07:27:22.287194	2017-01-08 07:27:22.287194
15	5	4	2017-01-08 07:27:22.288499	2017-01-08 07:27:22.288499
16	6	4	2017-01-08 07:27:22.290236	2017-01-08 07:27:22.290236
17	7	4	2017-01-08 07:27:22.291466	2017-01-08 07:27:22.291466
18	8	4	2017-01-08 07:27:22.292384	2017-01-08 07:27:22.292384
19	1	5	2017-01-08 07:58:20.243652	2017-01-08 07:58:20.243652
20	2	5	2017-01-08 07:58:20.245337	2017-01-08 07:58:20.245337
21	3	5	2017-01-08 07:58:20.246905	2017-01-08 07:58:20.246905
22	4	5	2017-01-08 07:58:20.248281	2017-01-08 07:58:20.248281
23	5	5	2017-01-08 07:58:20.24964	2017-01-08 07:58:20.24964
24	6	5	2017-01-08 07:58:20.274889	2017-01-08 07:58:20.274889
25	7	5	2017-01-08 07:58:20.276072	2017-01-08 07:58:20.276072
26	8	5	2017-01-08 07:58:20.277179	2017-01-08 07:58:20.277179
27	1	6	2017-01-08 08:03:57.902216	2017-01-08 08:03:57.902216
28	2	6	2017-01-08 08:03:57.904171	2017-01-08 08:03:57.904171
29	3	6	2017-01-08 08:03:57.905294	2017-01-08 08:03:57.905294
30	4	6	2017-01-08 08:03:57.906934	2017-01-08 08:03:57.906934
31	5	6	2017-01-08 08:03:57.908689	2017-01-08 08:03:57.908689
32	6	6	2017-01-08 08:03:57.911424	2017-01-08 08:03:57.911424
33	7	6	2017-01-08 08:03:57.912992	2017-01-08 08:03:57.912992
34	8	6	2017-01-08 08:03:57.914168	2017-01-08 08:03:57.914168
\.


--
-- TOC entry 2557 (class 0 OID 0)
-- Dependencies: 203
-- Name: departments_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('departments_events_id_seq', 34, true);


--
-- TOC entry 2558 (class 0 OID 0)
-- Dependencies: 186
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('departments_id_seq', 9, false);


--
-- TOC entry 2522 (class 0 OID 16395)
-- Dependencies: 187
-- Data for Name: employment_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY employment_types (id, name, created_at, updated_at) FROM stdin;
1	Full Time	2016-12-09 12:18:20.413312	2016-12-09 12:18:20.413312
2	Intern	2016-12-09 12:18:20.417378	2016-12-09 12:18:20.417378
3	Freelancer	2016-12-09 12:18:20.42084	2016-12-09 12:18:20.42084
\.


--
-- TOC entry 2559 (class 0 OID 0)
-- Dependencies: 188
-- Name: employment_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('employment_types_id_seq', 4, false);


--
-- TOC entry 2535 (class 0 OID 16519)
-- Dependencies: 200
-- Data for Name: enrollments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY enrollments (id, event_id, user_id, attended, feedback, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 2560 (class 0 OID 0)
-- Dependencies: 199
-- Name: enrollments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('enrollments_id_seq', 1, false);


--
-- TOC entry 2533 (class 0 OID 16498)
-- Dependencies: 198
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY events (id, name, event_type, description, organizer, started_at, ended_at, enroll_started_at, enroll_ended_at, capacity, public, remarks, user_id, status, created_at, updated_at) FROM stdin;
4	空军幼儿园员工饭堂报名	Others	<p>为能确保饭菜量的供应，请有意愿报名参加空军幼儿园员工饭堂堂食的同事，<strong><span style="color:#ff0000;">于11月22日</span></strong>（周二）中午14:00前确认及提交以下报名表，感谢你的参与！</p>\r\n\r\n<p><a href="/ckeditor_assets/attachments/6/.xlsx">饭堂报名表</a></p>\r\n\r\n<p><a href="/ckeditor_assets/attachments/7/饭堂报名表.xlsx">饭堂报名表</a></p>\r\n\r\n<p><a href="/ckeditor_assets/attachments/8/canteen.xlsx">饭堂报名</a></p>\r\n\r\n<p>&nbsp;</p>\r\n	XO Group	2016-11-22	2016-11-22	\N	\N	-1	t	\N	46	Draft	2017-01-08 07:27:22.278182	2017-01-09 00:01:36.694526
2	安卓开发培训第二期	Training	<p>我们的安卓开发培训二期将会在<span style="color:#ff0000;">Aug.27(Saturday)</span>进行，请大家在<b><span style="color:#ff0000;">7月29日</span>18:00pm前</b>到Kammy 处报名。</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>培训时间：2016年8月27日 &nbsp;10:00-17:30</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>培训地点：广州市天河路365号天俊国际大厦7楼（详细参见附件）</p>\r\n\r\n<p>培训大纲：请见附件</p>\r\n	广州嘉为培训	2016-08-27	2016-08-27	\N	\N	-1	t	\N	46	Draft	2017-01-06 17:34:54.041855	2017-01-06 17:40:35.476913
1	安卓开发培训第一期	Training	<p>我们的安卓开发培训将会在<span style="color:#ff0000;">Aug.13(Saturday) </span>进行，请大家在<b><span style="color:#ff0000;">7月29日</span>18:00pm前</b>到Kammy 处报名。</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>培训时间：2016年8月13日 &nbsp;10:00-17:30</p>\r\n\r\n<p>培训地点：广州市天河路365号天俊国际大厦7楼（详细参见附件）</p>\r\n\r\n<p>培训大纲：请见附件</p>\r\n	广州嘉为培训	2016-08-13	2016-08-13	\N	\N	-1	t	\N	46	Draft	2017-01-06 17:32:32.858301	2017-01-06 17:40:46.807047
3	桂林之旅2016	Outing	<p>公司旅游即将到来，帅锅美铝们约吗？<span style="color:#ff0000;"><strong>2016年9月23日到9月25日</strong></span> 我们将携手一起踏上诺特桂林之旅，共同走访六百多年的历史古迹，欣赏如梦似幻的歌舞剧，体验壮丽秀美的世界梯田，感受画卷般的阳朔风光。</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>届时我们将有两条路线，一为<b>A队</b>路线，二为<b>B队</b>路线，帅锅美铝们可自行选择其中一条路线，具体请查看以下行程安排：</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>第 1 日：</p>\r\n\r\n<p><b>AB队</b>【广州】--【桂林】--【靖江王府】--【梦幻漓江】</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>第 2 日：</p>\r\n\r\n<p><b>A队</b>【龙脊梯田】--【桂林】</p>\r\n\r\n<p><b>B队</b>【兴坪渔村】-【遇龙河竹筏漂流】-【桂林】</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>第 3 日：</p>\r\n\r\n<p><b>AB队</b>【象鼻山】-【广州】</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>以上行程由旅行社提供，仅供参考，如有改动，另行通知。请大家在<b>2016年8月23日12:00p.m.</b><b>前</b>移步到Admin Kammy/Jane处报名，逾期不候，不便之处请见谅，谢谢。</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img alt="" src="/ckeditor_assets/pictures/1/content_image1.png" style="width: 641px; height: 324px;" /></p>\r\n\r\n<p><img alt="" src="/ckeditor_assets/pictures/2/content_image2.png" style="width: 641px; height: 394px;" /></p>\r\n\r\n<p><img alt="" src="/ckeditor_assets/pictures/3/content_image3.png" style="width: 641px; height: 376px;" /></p>\r\n\r\n<p><img alt="" src="/ckeditor_assets/pictures/4/content_image4.png" style="width: 641px; height: 521px;" /></p>\r\n\r\n<p><img alt="" src="/ckeditor_assets/pictures/5/content_image5.png" style="width: 641px; height: 409px;" /></p>\r\n	XO Group	2016-09-23	2016-09-25	\N	\N	-1	t	\N	46	Draft	2017-01-06 18:54:33.52533	2017-01-07 01:26:42.692157
5	海泉湾温泉之旅	Outing	<p>大家好，即将到来的海泉湾温泉之旅，以下是需要大家注意的事项，为了旅途的欢快和安全，请大家务必仔细阅读：</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>1.以下集中时间，请大家务必准时。</p>\r\n\r\n<p><b>（1）12月25日(周日）： 9:15am.天伦大厦门口集中（公司提供早餐），9：30am.准时出发</b></p>\r\n\r\n<p>（2）12月26日（周一）： 8:45am.退房，9:00am.酒店大堂集中，出发前往珠海长隆</p>\r\n\r\n<p>（3）12月26日（周一）： 16:00pm.回程，集中地点待定</p>\r\n\r\n<p>2.请将<strong><span style="color:#ff0000;">身份证原件</span></strong>带上。</p>\r\n\r\n<p>3.请自备泳衣，泳裤和泳帽；</p>\r\n\r\n<p>4.请按附件中的表格明确各自的分组，并以分组名单进行分桌，旅程中均按附件中表格的桌号进行就坐。</p>\r\n\r\n<p>5.所有行程中，分有3部大巴，请按对应车次1车2车3车进行乘车。</p>\r\n\r\n<p>6.天气变化，请大家注意带好衣物和雨具。</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>PS：附件为行程、分组分车名单以及温泉注意事项。</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><a href="/ckeditor_assets/attachments/10/%E6%B8%A9%E6%B3%89%E6%B3%A8%E6%84%8F%E4%BA%8B%E9%A1%B9.docx">温泉注意事项</a></p>\r\n	XO Group	2016-12-25	2016-12-26	\N	\N	-1	t	\N	46	Draft	2017-01-08 07:58:20.241333	2017-01-08 07:58:20.241333
6	Annual dinner 2017	Outing	<p>We take pleasure in inviting you to GZ office annual dinner on Wednesday, Jan 11th, 2017. The annual dinner will be held at 天河区华穗路406号保利克洛维二期四楼.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>As it is an organizational event. This means you are requested to dress <b>smart casual</b> attire.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Please make sure to inform Kammy till Monday, Jan 9th, 2017 in case if you are unable to attend the party.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>We hope you would be able to join us on this great yearly occasion and looking forward to meeting you in the venue. Thank you.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img alt="" src="/ckeditor_assets/pictures/11/content_image.png" style="width: 400px; height: 302px;" /></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><a href="http://map.baidu.com/?newmap=1&amp;s=inf%26uid%3D0785f57d85ae9339d8ecedc7%26wd%3D%E5%B9%BF%E5%B7%9E%E5%85%B4%E6%82%A6%E9%85%92%E5%AE%B6%26all%3D1%26c%3D257&amp;from=alamap&amp;tpl=mapdots"><b>Venue Map</b></a></p>\r\n\r\n<p>&nbsp;</p>\r\n	XO Group	2017-01-11	2017-01-11	\N	\N	-1	t	\N	46	Draft	2017-01-08 08:03:57.899777	2017-01-08 08:03:57.899777
\.


--
-- TOC entry 2561 (class 0 OID 0)
-- Dependencies: 197
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('events_id_seq', 6, true);


--
-- TOC entry 2524 (class 0 OID 16403)
-- Dependencies: 189
-- Data for Name: job_titles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY job_titles (id, name, created_at, updated_at, is_active) FROM stdin;
1	Senior Software Engineer	2016-12-09 12:18:20.211392	2016-12-09 12:18:20.211392	t
2	Tech Support Engineer	2016-12-09 12:18:20.215692	2016-12-09 12:18:20.215692	t
3	Mobile Engineer II	2016-12-09 12:18:20.219215	2016-12-09 12:18:20.219215	t
4	Lead Admin & HR Officer	2016-12-09 12:18:20.222751	2016-12-09 12:18:20.222751	t
5	Lead Software Engineer	2016-12-09 12:18:20.226269	2016-12-09 12:18:20.226269	t
6	Mobile Developer	2016-12-09 12:18:20.229709	2016-12-09 12:18:20.229709	t
7	Accounting Manager	2016-12-09 12:18:20.233156	2016-12-09 12:18:20.233156	t
8	Senior Development Manager	2016-12-09 12:18:20.236681	2016-12-09 12:18:20.236681	t
9	Senior QA Engineer	2016-12-09 12:18:20.240214	2016-12-09 12:18:20.240214	t
10	Assistant Lead Software Engineer	2016-12-09 12:18:20.243645	2016-12-09 12:18:20.243645	t
11	Lead QA Engineer	2016-12-09 12:18:20.247025	2016-12-09 12:18:20.247025	t
12	Data Auditor I	2016-12-09 12:18:20.250503	2016-12-09 12:18:20.250503	t
13	QA Manager	2016-12-09 12:18:20.253974	2016-12-09 12:18:20.253974	t
14	QA Engineer II	2016-12-09 12:18:20.257433	2016-12-09 12:18:20.257433	t
15	Software Engineer II	2016-12-09 12:18:20.260903	2016-12-09 12:18:20.260903	t
16	Senior Project Manager	2016-12-09 12:18:20.26456	2016-12-09 12:18:20.26456	t
17	Assistant Development Manager	2016-12-09 12:18:20.268108	2016-12-09 12:18:20.268108	t
18	Lead DBA	2016-12-09 12:18:20.271754	2016-12-09 12:18:20.271754	t
19	Ad Trafficker	2016-12-09 12:18:20.275673	2016-12-09 12:18:20.275673	t
20	Assistant Project Manager	2016-12-09 12:18:20.27938	2016-12-09 12:18:20.27938	t
21	Assistant QA Manager	2016-12-09 12:18:20.283124	2016-12-09 12:18:20.283124	t
22	Project Coordinator	2016-12-09 12:18:20.286644	2016-12-09 12:18:20.286644	t
23	Admin assistance	2016-12-09 12:18:20.290095	2016-12-09 12:18:20.290095	t
24	Senior Data Auditor	2016-12-09 12:18:20.293604	2016-12-09 12:18:20.293604	t
25	UI Designer	2016-12-09 12:18:20.297119	2016-12-09 12:18:20.297119	t
26	Senior Report Producer	2016-12-09 12:18:20.307852	2016-12-09 12:18:20.307852	t
27	Senior Lead Sofware Engineer	2016-12-09 12:18:20.311407	2016-12-09 12:18:20.311407	t
28	Admin Assistant	2016-12-09 12:18:20.314903	2016-12-09 12:18:20.314903	t
29	Infrastructure Manager	2016-12-09 12:18:20.318342	2016-12-09 12:18:20.318342	t
30	Ad Trafficker II	2016-12-09 12:18:20.321829	2016-12-09 12:18:20.321829	t
31	QA Engineer I	2016-12-09 12:18:20.325319	2016-12-09 12:18:20.325319	t
32	Senior software Engineer	2016-12-09 12:18:20.32896	2016-12-09 12:18:20.32896	t
33	Junior Accountant	2016-12-09 12:18:20.332655	2016-12-09 12:18:20.332655	t
34	Assistant Ad Trafficking Manager	2016-12-09 12:18:20.336214	2016-12-09 12:18:20.336214	t
35	Data Auditor II	2016-12-09 12:18:20.339669	2016-12-09 12:18:20.339669	t
36	HR Manager	2016-12-09 12:18:20.343238	2016-12-09 12:18:20.343238	t
37	Assistant Lead Designer	2016-12-09 12:18:20.346989	2016-12-09 12:18:20.346989	t
38	Software Engineer I	2016-12-09 12:18:20.350719	2016-12-09 12:18:20.350719	t
39	Assistant Manager	2016-12-09 12:18:20.354372	2016-12-09 12:18:20.354372	t
40	Development Manager	2016-12-09 12:18:20.357922	2016-12-09 12:18:20.357922	t
41	Assistant Ad report producer Manager	2016-12-09 12:18:20.361477	2016-12-09 12:18:20.361477	t
42	Senior Ad trafficker	2016-12-09 12:18:20.364964	2016-12-09 12:18:20.364964	t
43	Project Manager	2016-12-09 12:18:20.368563	2016-12-09 12:18:20.368563	t
44	Mobile Engineer II - iOs	2016-12-09 12:18:20.372171	2016-12-09 12:18:20.372171	t
45	Architect Manager	2016-12-09 12:18:20.375881	2016-12-09 12:18:20.375881	t
46	Designer	2016-12-09 12:18:20.379338	2016-12-09 12:18:20.379338	t
47	Report Producer I	2016-12-09 12:18:20.382956	2016-12-09 12:18:20.382956	t
48	General Manager of GZSDC	2016-12-09 12:18:20.386498	2016-12-09 12:18:20.386498	t
49	Architect Director	2016-12-09 12:18:20.390041	2016-12-09 12:18:20.390041	t
50	Systems Director	2016-12-09 12:18:20.393584	2016-12-09 12:18:20.393584	t
51	General Manager of Asia	2016-12-09 12:18:20.397097	2016-12-09 12:18:20.397097	t
53	System Support Engineer	2016-12-21 14:33:30.049962	2016-12-21 14:33:30.049962	t
54	Mobile Engineer	2016-12-21 14:48:31.904112	2016-12-21 14:48:31.904112	t
55	Salesforce Admin II	2016-12-21 15:21:38.899796	2016-12-21 15:21:38.899796	t
56	Mobile Engineer - IOS	2016-12-21 15:41:23.365859	2016-12-21 15:41:23.365859	t
57	Report Producer II	2016-12-21 15:49:05.547109	2016-12-21 15:49:05.547109	t
58	Assistant QA Lead	2016-12-21 15:55:31.453419	2016-12-21 15:55:31.453419	t
59	Admin&HR officer I	2016-12-21 16:31:39.410359	2016-12-21 16:31:39.410359	t
60	Project Coordinator II	2016-12-21 16:34:53.705937	2016-12-21 16:34:53.705937	t
61	Ad trafficker I	2016-12-21 17:02:14.787432	2016-12-21 17:02:14.787432	t
62	Sales Support Manager	2016-12-21 17:19:50.897721	2016-12-21 17:19:50.897721	t
63	General Manager	2016-12-21 17:57:27.970017	2016-12-21 17:57:27.970017	t
52	QA Director	2016-12-09 12:18:20.400663	2016-12-22 12:40:27.404959	f
\.


--
-- TOC entry 2562 (class 0 OID 0)
-- Dependencies: 190
-- Name: job_titles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('job_titles_id_seq', 63, true);


--
-- TOC entry 2530 (class 0 OID 16480)
-- Dependencies: 195
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY schema_migrations (version) FROM stdin;
20161227072234
20161230074844
20161230183841
20170104084317
\.


--
-- TOC entry 2526 (class 0 OID 16412)
-- Dependencies: 191
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: -
--

COPY teams (id, name, leader_id, created_at, updated_at, is_active) FROM stdin;
1	Media Solutions (Platforms)	\N	2016-12-09 12:18:20.066929	2016-12-09 12:18:20.066929	t
2	Tech Services	\N	2016-12-09 12:18:20.071718	2016-12-09 12:18:20.071718	t
3	Native Mobile App	\N	2016-12-09 12:18:20.075203	2016-12-09 12:18:20.075203	t
4	HR & Admin	\N	2016-12-09 12:18:20.078675	2016-12-09 12:18:20.078675	t
5	Finance	\N	2016-12-09 12:18:20.082176	2016-12-09 12:18:20.082176	t
6	MarketPlace & The Bump	\N	2016-12-09 12:18:20.085616	2016-12-09 12:18:20.085616	t
7	Corporate Systems	\N	2016-12-09 12:18:20.089126	2016-12-09 12:18:20.089126	t
8	The Bump	\N	2016-12-09 12:18:20.092755	2016-12-09 12:18:20.092755	t
9	Shared - QA	\N	2016-12-09 12:18:20.096273	2016-12-09 12:18:20.096273	t
10	Data Intelligence	\N	2016-12-09 12:18:20.099672	2016-12-09 12:18:20.099672	t
11	Registry	\N	2016-12-09 12:18:20.103043	2016-12-09 12:18:20.103043	t
12	Media Solutions & The Nest	\N	2016-12-09 12:18:20.106559	2016-12-09 12:18:20.106559	t
13	Media Solutions	\N	2016-12-09 12:18:20.109959	2016-12-09 12:18:20.109959	t
14	DB and Architecture	\N	2016-12-09 12:18:20.113383	2016-12-09 12:18:20.113383	t
15	Tools & Media Solutions	\N	2016-12-09 12:18:20.117649	2016-12-09 12:18:20.117649	t
16	Ad Trafficker	\N	2016-12-09 12:18:20.121381	2016-12-09 12:18:20.121381	t
17	MarketPlace (Local Core)	\N	2016-12-09 12:18:20.124925	2016-12-09 12:18:20.124925	t
18	Tools	\N	2016-12-09 12:18:20.128385	2016-12-09 12:18:20.128385	t
19	Design	\N	2016-12-09 12:18:20.132558	2016-12-09 12:18:20.132558	t
20	Reporting	\N	2016-12-09 12:18:20.13653	2016-12-09 12:18:20.13653	t
21	Media Solutions (Ad Tech)	\N	2016-12-09 12:18:20.140184	2016-12-09 12:18:20.140184	t
22	MarketPlace	\N	2016-12-09 12:18:20.144027	2016-12-09 12:18:20.144027	t
23	Reporting & Concierge	\N	2016-12-09 12:18:20.147656	2016-12-09 12:18:20.147656	t
24	The Nest	\N	2016-12-09 12:18:20.151245	2016-12-09 12:18:20.151245	t
25	MGT	\N	2016-12-09 12:18:20.154821	2016-12-09 12:18:20.154821	t
26	Vendor Experience	\N	2016-12-21 14:20:06.358981	2016-12-21 14:20:06.358981	t
27	Mobile	\N	2016-12-21 14:36:13.593496	2016-12-21 14:36:13.593496	t
28	TwoBrightLights	\N	2016-12-21 15:09:25.711797	2016-12-21 15:09:25.711797	t
29	Architecture & DBA	\N	2016-12-21 15:51:01.05809	2016-12-21 15:51:14.725659	t
30	Architecture & DBA	\N	2016-12-21 17:49:06.18276	2016-12-21 17:49:06.18276	t
\.


--
-- TOC entry 2563 (class 0 OID 0)
-- Dependencies: 192
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('teams_id_seq', 30, true);


--
-- TOC entry 2528 (class 0 OID 16421)
-- Dependencies: 193
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, created_at, updated_at, first_name, last_name, chinese_name, gender, on_board_at, birthday_month, department_id, job_title_id, team_id, tokens, provider, uid, on_resigned_at, status, id_card, role, manager_id, employment_type_id, contract_end_date) FROM stdin;
27	fchen@xogrp.com	$2a$11$nOxdw2fjB.bXHzkLlDXTeOXccIVIH2R8/VngsI5xyZXAmjhfsQLfC	\N	\N	\N	1	2016-12-23 11:26:00.467219	2016-12-23 11:26:00.467219	172.26.10.66	172.26.10.66	2016-12-09 12:18:20.734207	2016-12-23 11:26:00.468596	Fred	Chen	陈灿烽	1	2013-12-04	9	1	1	27	{"UyduKzFlLx-dfMk9Lkpq_g":{"token":"$2a$10$dw2B2T2ucC8u4XY/OZUSg.QsnE.Yp9.qazjrudw7ymPZ9dYoxGTZS","expiry":1483673160}}	email	fchen@xogrp.com	\N	1	    0   	User	22	1	\N
8	aan@xogrp.com	$2a$11$1LvJ85chqH0Sgd3dDl9kIOiWBELzJ/XRoh1YOJblvSJ8y6IhRtvIC	\N	\N	\N	1	2016-12-28 16:46:24.771914	2016-12-28 16:46:24.771914	172.26.0.17	172.26.0.17	2016-12-09 12:18:20.574897	2016-12-28 16:46:24.773579	Andy	An	安宏猷	1	2009-05-18	8	1	8	26	{"flmstk6RVnO3EVmdvaw_9Q":{"token":"$2a$10$ApuZNvWbrgeSzi4Pj.uHluUXeb/upBV8i1KQ5Udh1Wol92YaAZvBe","expiry":1484124384}}	email	aan@xogrp.com	\N	1	0    	User	112	1	\N
33	hzeng@xogrp.com	$2a$11$PRgdGW9gFcEm1rQDB9zAO.rqsyPYvYXPBWE1carrknuumRDXdwJUu	\N	\N	\N	2	2016-12-29 18:46:41.524513	2016-12-23 11:53:17.480049	172.26.11.112	172.26.11.112	2016-12-09 12:18:20.774184	2016-12-29 18:46:41.5262	Helen	Zeng	曾姣	0	2015-04-14	4	1	15	18	{"z1h08v0GM-D1RKhniGiRnA":{"token":"$2a$10$Fg0Tt0tLuLtH2.q5Mi.KnunjrBuQqfnpDcCkJP0DrEgSYM6k6n5AK","expiry":1484218001}}	email	hzeng@xogrp.com	\N	1	   0      	User	38	1	\N
10	ahuang@xogrp.com	$2a$11$dw/.H2pvGNWG8B9NRKjm..5TMnSV5oqgeSgMrAgxMmkg/6Uw3aXX6	\N	\N	\N	1	2016-12-23 11:59:26.007935	2016-12-23 11:59:26.007935	172.26.0.32	172.26.0.32	2016-12-09 12:18:20.590744	2016-12-23 11:59:26.009272	Arthur	Huang	黄汉硕	1	2014-05-04	4	1	10	8	{"OJu5v6rSge7UxXunHob_Bg":{"token":"$2a$10$.Ja2BArhw.nfZrpFLwkMj.qoqePj.ZKbcv4Vm0gGHyfJkRcLOSf4.","expiry":1483675165}}	email	ahuang@xogrp.com	\N	1	       0	User	8	1	\N
6	azhou@xogrp.com	$2a$11$OrEpGYN8/UGVVxPJZHRHKeiMXkq2DRnL6rfnKA5LYqJuT55MjUNKW	\N	\N	\N	1	2016-12-28 11:19:37.918343	2016-12-28 11:19:37.918343	172.26.0.32	172.26.0.32	2016-12-09 12:18:20.55927	2016-12-28 11:19:37.919763	Almin	Zhou	周永明	1	2014-10-08	3	7	3	27	{"LjQLM7Paz9d0XR4ecpsuVg":{"token":"$2a$10$QtH.lcdJOFHi93VW2QmhY.f0YzHGPdKbMD2P.rWlMuOoN6hzd49.m","expiry":1484104777}}	email	azhou@xogrp.com	\N	1	   0	User	22	1	\N
21	bzhou@xogrp.com	$2a$11$21dSnk7w5BEqyDCVZBnsse92QJe1bMpPr9s3mtzEX87lhcBTlIsyu	\N	\N	\N	1	2016-12-27 17:02:15.081474	2016-12-27 17:02:15.081474	172.26.0.32	172.26.0.32	2016-12-09 12:18:20.677745	2016-12-27 17:02:15.08294	Denny	Zhou	周梓佳	1	2016-04-11	4	1	15	11	{"IsDfZfu_QfQE2Ghp6T4XNQ":{"token":"$2a$10$YQ1/jH8Qnv1Sune04OBphOgwiQ8Wkt6/0eZdo7H.rxCmFZCPy5P1u","expiry":1484038935}}	email	bzhou@xogrp.com	\N	1	   0     	User	80	1	\N
25	evli@xogrp.com	$2a$11$ZbJRbrET1oQn0JtQVS5m/eaNIYJvDiQO/rh1s7O4hWBn8RiognvOm	\N	\N	\N	1	2016-12-28 14:22:14.40285	2016-12-28 14:22:14.40285	172.26.0.17	172.26.0.17	2016-12-09 12:18:20.720917	2016-12-28 14:22:14.404172	Evan	Li	李晓波	1	2015-11-16	11	1	15	18	{"rQxN9rzQi8uf-ZiNs5WQxw":{"token":"$2a$10$w/GZ57Pg5LpKmTSny8dLeuHLpDrwzovIi9JS34vEqtsx83vI6wuha","expiry":1484115734}}	email	evli@xogrp.com	\N	1	         0	User	38	1	\N
5	azheng@xogrp.com	$2a$11$Mx21g9yStlgXyZ3J.jVE2O0CAdVKqwF5LPIwdUxlWT.xbWN..9EL6	\N	\N	\N	1	2016-12-30 10:37:07.74927	2016-12-30 10:37:07.74927	172.26.0.17	172.26.0.17	2016-12-09 12:18:20.551122	2016-12-30 10:37:07.750605	Allen	Zheng	郑旭林	1	2013-09-09	12	1	5	18	{"7eDbMi3kiFzVV2BAymP1Lw":{"token":"$2a$10$AKNOuklDis8zM.hIPj0mLu3LozcKiVR0sxL9y50F5CfYkIg1EedZi","expiry":1484275027}}	email	azheng@xogrp.com	\N	1	  0	User	38	1	\N
4	aqiu@xogrp.com	$2a$11$qRLPK5JN3r73g68xDuxId.KjHmvPMyPdH3zNhVDA0obVup14//9Pu	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.543237	2016-12-21 14:38:11.398944	Alex	Qiu	邱国樑	1	2011-12-05	7	3	4	4	{}	email	aqiu@xogrp.com	\N	1	 0	User	68	1	\N
7	ajiang@xogrp.com	$2a$11$UOLucMwE6foEUzJQ5RLIjukyizY8Hp/JyubFxY5DzUIXsXHs8nuWC	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.567062	2016-12-21 14:50:44.497374	Amy	Jiang	江金霞	0	2011-02-14	12	3	7	5	{}	email	ajiang@xogrp.com	\N	1	     0	User	109	1	\N
9	asu@xogrp.com	$2a$11$HSe6szYIbN5uj226FXSzWO9a/5pWZ24cTk9TgknXsasKLX7L8QdIi	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.582835	2016-12-21 14:59:04.747293	Anthony	Su	苏冠铭	1	2015-09-21	4	4	9	7	{}	email	asu@xogrp.com	\N	1	0      	User	14	1	\N
13	bdeng@xogrp.com	$2a$11$qn.jm1RHFmkA65C60v1XHeM2noxwEpGtH.N/mt/5sYnNNggu21IuG	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.61521	2016-12-21 15:10:58.297862	Brandon	Deng	邓子洋	1	2015-04-20	8	5	35	10	{}	email	bdeng@xogrp.com	\N	1	 0      	User	83	1	\N
14	cyang@xogrp.com	$2a$11$tLU1hLD2ux9GP4SDLQsT2e4Zee9gASVQLIHr3iiZRkH.N./xsAuNi	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.623155	2016-12-21 15:12:52.265442	Calla	Yang	阳彩虹	0	2010-03-08	6	4	13	27	{}	email	cyang@xogrp.com	\N	1	  0  	User	109	1	\N
16	csun@xogrp.com	$2a$11$Gsm8612.VxYMf8vGA26To.6ZvtH1zzvGbBY7g563DLv4hdP49IJKi	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.639257	2016-12-21 15:14:17.764555	Cathy	Sun	孙迎春	0	2015-05-25	2	4	14	7	{}	email	csun@xogrp.com	\N	1	  0   	User	14	1	\N
15	canguo@xogrp.com	$2a$11$EQ6nF8xVoeTQyk4cF0c9ZeBeFGl5zxoprjdRgcBxoCjqiy4YPgwwy	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.630968	2016-12-21 15:14:47.915592	Candy	Guo	郭惠娜	0	2015-03-30	6	5	12	10	{}	email	canguo@xogrp.com	\N	0	\N	User	\N	1	\N
17	chandlerh@xogrp.com	$2a$11$uB2TQPGbzMJXauY3SgCN7etCqjw0BKppxRCF.lXbnVBKEUUDJRAiK	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.646839	2016-12-21 15:18:37.785442	Chandler	Huang	黄春东	1	2012-04-09	6	1	5	11	{}	email	chandlerh@xogrp.com	\N	1	 0  	User	\N	1	\N
18	cfeng@xogrp.com	$2a$11$5QU6BojwSuCiT.SZvtX/b.2LeQcvQGiovhP2bOf8pr/KoNY6q/rEy	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.654864	2016-12-21 15:23:07.04967	Chris	Feng	冯浩钊	1	2015-08-17	3	1	15	11	{}	email	cfeng@xogrp.com	\N	0	\N	User	\N	1	\N
19	cgu@xogrp.com	$2a$11$PGip4XtyTQmKIAUQWo.C3etYwE2F0NYzEIdkymoOz.FRJkEiBycEm	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.662491	2016-12-21 15:26:54.205524	Cruze	Gu	古宇昇	1	2015-01-15	2	1	1	11	{}	email	cgu@xogrp.com	\N	1	 0       	User	80	1	\N
20	dxiao@xogrp.com	$2a$11$4XOJohOK9xLzzWMoealy.uEQbToeFuFfGjspP1XXq8o5R39CjiX9q	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.670172	2016-12-21 15:30:50.502962	Daisy	Xiao	萧梅妹	0	2010-04-06	10	6	16	18	{}	email	dxiao@xogrp.com	\N	1	   0  	User	111	1	\N
23	ehu@xogrp.com	$2a$11$0dLvC9rCMSouqA92O/TrY.qA8EzUdnIEuAOx9Xnvrg.7jJNdK6gwO	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.706738	2016-12-21 15:46:57.175949	Elaine	Hu	胡苑源	0	2013-10-08	5	4	9	18	{}	email	ehu@xogrp.com	\N	1	      0  	User	14	1	\N
24	eliu@xogrp.com	$2a$11$Pi/N53ZGN5o34JTTPWecFOQVi9MYdtpCGtAuKLAIj.luVv93g7Aum	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.714373	2016-12-21 15:51:37.259682	Eric	Liu	刘敖	1	2009-10-20	12	2	18	29	{}	email	eliu@xogrp.com	\N	1	       0 	User	110	1	\N
30	hhuang@xogrp.com	$2a$11$sJySGC3gk.0q7aSsoLdq/uT/a4vgJNKiXuFu0Tx4vnJjYyZTK14fe	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.754367	2016-12-21 16:05:14.589264	Hailey	Huang	黄海丽	0	2010-01-04	1	6	20	17	{}	email	hhuang@xogrp.com	\N	0	\N	User	\N	1	\N
31	hchen@xogrp.com	$2a$11$O/dE0srRvSh4/iGtFvRX9.d46PM6koYw1ZfxhBoX/SEjQobgUJnuy	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.76097	2016-12-21 16:05:48.211473	Hanks	Chen	陈子豪	1	2016-05-03	11	5	12	10	{}	email	hchen@xogrp.com	\N	1	  0      	User	83	1	\N
32	hazeng@xogrp.com	$2a$11$M9Ujn2M9myd2alLzTNnNWOCQALgRv9A6U6VjibMKcCqSZXS4RJGd6	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.767609	2016-12-21 16:06:33.694525	Harris	Zeng	曾志洪	1	2015-07-15	5	1	10	18	{}	email	hazeng@xogrp.com	\N	1	  0       	User	38	1	\N
34	iwu@xogrp.com	$2a$11$mFc9C31qZtOAkpSqnuWk3.NTv.GGZE/LFgp4zpRFhKdmf6HpbuFYW	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.78102	2016-12-21 16:12:29.840545	Ivy	Wu	伍艳娜	0	2010-06-07	12	4	21	11	{}	email	iwu@xogrp.com	\N	1	0          	User	14	1	\N
48	wzhong@xogrp.com	$2a$11$QpmFStQtr9BzN6esh65CSOld2seMyk/J4eGMRA42LT5hetz2eyAZK	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.875535	2016-12-21 16:36:58.662153	Kelvin	Zhong	钟伟志	1	2009-05-18	12	2	29	2	{}	email	wzhong@xogrp.com	\N	1	0            	User	109	1	\N
49	kyu@xogrp.com	$2a$11$1S1l.QU/QtwuXfcut3lnf.ReMT9QECzGTqx1DOYOFNS90MlG.EzU.	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.882103	2016-12-21 16:37:46.179222	Kira	Yu	余玉琴	0	2015-06-23	1	6	22	18	{}	email	kyu@xogrp.com	\N	1	 0            	User	111	1	\N
50	kyuan@xogrp.com	$2a$11$nX6DHUJgup2/y2JWNKiLGOzZvz8bhEXnbXY1LpJZ2QJpFtj0glJIy	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.888779	2016-12-21 16:38:05.824431	Kirin	Yuan	袁伟麟	1	2016-03-17	10	1	15	17	{}	email	kyuan@xogrp.com	\N	0	\N	User	\N	1	\N
51	kiwang@xogrp.com	$2a$11$WYmHT0OpK8wVAeAIDIWVh.UeoxCzaWBFUgK.GluoNMBzXacuZbn8y	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.895493	2016-12-21 16:38:39.475516	Kitty	Wang	王诗薇	0	2015-06-15	3	5	30	16	{}	email	kiwang@xogrp.com	\N	1	 0          	User	63	1	\N
54	lye@xogrp.com	$2a$11$18wmpYQwfq3KAcvRzmeUY.05WijJYFojseHAr84tyhDviyh/GfT5G	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.915609	2016-12-21 16:48:27.082294	Leon	Ye	叶彬彬	1	2016-06-13	12	1	15	18	{}	email	lye@xogrp.com	\N	1	      0        	User	38	1	\N
56	llian@xogrp.com	$2a$11$bzbghom8n29zEGK15YJoWOtfSAgjlwqUqQh.dI4/B2MblgMqPidYm	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.928919	2016-12-21 16:50:27.505482	Lindsey	Lian	练智雯	0	2015-12-01	8	6	22	11	{}	email	llian@xogrp.com	\N	1	      0         	User	111	1	\N
151	than@xogrp.com	$2a$11$w6/W2r/uSiX2rcupFp/t0.X/wkPAesRlm0V0SAGQzcC2VHHU0ePYe	\N	\N	\N	0	\N	\N	\N	\N	2016-12-29 16:11:17.978735	2016-12-29 16:11:17.978735	Tim	Han	韩嘉浚	1	2016-12-20	5	3	4	4	{}	email	than@xogrp.com	\N	1	19	User	68	1	\N
59	lyi@xogrp.com	$2a$11$vfB4pLTgxzwyMvmkUZkYceJDqA5mLrpdgmLJPmHKoj6/Bl7qeQg0y	\N	\N	\N	2	2016-12-28 10:42:29.690812	2016-12-23 12:13:22.587027	172.26.10.151	172.26.10.22	2016-12-09 12:18:20.949374	2016-12-28 10:42:29.692567	Lucky	Yi	易贤武	1	2010-03-08	10	1	27	26	{"TO6Jj2bLsa1n8L8pU76qXg":{"token":"$2a$10$FU2SgIUshbA8eskVwypWvOTySrP9NmuLXXTRigdXxJ/MlafTWZbme","expiry":1483676002},"g-DQJXlTTwZcxuHwI-T5TA":{"token":"$2a$10$abwT3qc3F0sRB0D7AqVIAOwJMK/NHl/prqfU0Q.kDHVVNQUvxaI1a","expiry":1484102549}}	email	lyi@xogrp.com	\N	1	      0           	User	8	1	\N
44	jfeng@xogrp.com	$2a$11$.wik1RF71dzfLqZ6b7tIq.0BiF0cn6o5DrqqaxzP8MPvtq0cyI9N.	\N	\N	\N	1	2016-12-29 10:08:38.733917	2016-12-29 10:08:38.733917	172.26.0.17	172.26.0.17	2016-12-09 12:18:20.848784	2016-12-29 10:08:38.735376	Joyce	Feng	冯海平	0	2013-01-28	10	5	26	20	{"vZDy7uNKNwQPl2tjTdGD8A":{"token":"$2a$10$kRlyv1s3cfOcGm4zad7Tb.7Lwq2FrOgwvMpaa53C4pHk3MazbEyfW","expiry":1484186918}}	email	jfeng@xogrp.com	\N	1	 0     	User	83	1	\N
63	mfu@xogrp.com	$2a$11$VSzQx4yIqE9RacOlP9P/qOU6dYetONu7pztaRVJVjcWIiJRbGgth6	\N	\N	\N	1	2016-12-23 18:03:24.088556	2016-12-23 18:03:24.088556	172.26.0.32	172.26.0.32	2016-12-09 12:18:20.976218	2016-12-23 18:03:24.090044	May	Fu	符妹	0	2013-04-23	10	5	34	16	{"1ubYNoPqIDD5IOesSmnoFQ":{"token":"$2a$10$.2QnDKVyClfaojKVCF0omOidlQ2sRcaBoAIVwcsM5WaYuH33U0Eg2","expiry":1483697004}}	email	mfu@xogrp.com	\N	1	     0          	User	109	1	\N
36	jli@xogrp.com	$2a$11$hDBLyZ.DRcmqAf.UGhvxo.90c6SdAYLlaFiR5X1eFErYqWWeCw7Hy	\N	\N	\N	1	2016-12-27 19:59:41.196648	2016-12-27 19:59:41.196648	172.26.0.17	172.26.0.17	2016-12-09 12:18:20.794436	2016-12-27 19:59:41.198068	Jane	Li	黎伙兰	0	2009-07-01	2	3	23	4	{"dqaE_8qEpqBVT6OdGnB3BA":{"token":"$2a$10$owc6wVESQp8cB3R/IgwaV.pDQ9KtynShX2Pe7Ad7CjOas8.c5OJwi","expiry":1484049581}}	email	jli@xogrp.com	\N	1	   0       	User	68	1	\N
60	lyli@xogrp.com	$2a$11$ghO.kU2Vt6m.Mw2zuH7PFeqfDIeuhM6ABfV2ciRprcW1XgInxXG2e	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.956133	2016-12-21 16:55:28.505554	Lynn	Li	李江	0	2015-06-18	12	4	14	27	{}	email	lyli@xogrp.com	\N	1	           0     	User	14	1	\N
57	lolin@xogrp.com	$2a$11$sa..nBzpa.8ORquXGMItkujVjT.r1gouMQzh/RQLxmMqHCSEweYRS	\N	\N	\N	1	2016-12-28 09:58:08.594855	2016-12-28 09:58:08.594855	172.26.0.17	172.26.0.17	2016-12-09 12:18:20.935643	2016-12-28 09:58:08.596244	Lonnie	Lin	林文烁	1	2016-06-06	5	5	12	10	{"uL1p50klQshg8HV-TNN0Sg":{"token":"$2a$10$v/ObTsDWvT7U/4lik11UUegIPgMkyOCYEcsQw5DwOtqQJjwYQi6kW","expiry":1484099888}}	email	lolin@xogrp.com	\N	1	0               	User	83	1	\N
61	mou@xogrp.com	$2a$11$0ASjyB7J0bJdg7rNZZROCeaRHnJ46MRr0/hR.tWhyfEeJBV4yFanu	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.962731	2016-12-21 16:56:01.880636	Maksim	Ou	区为佳	1	2015-01-12	10	1	32	18	{}	email	mou@xogrp.com	\N	1	     0      	User	38	1	\N
42	jwu@xogrp.com	$2a$11$0WXym.9s1dKtgvisUHmkt.5dQl.D1FdQgxJyBNn3yOXuapjEsD7Em	\N	\N	\N	1	2016-12-28 12:35:22.459531	2016-12-28 12:35:22.459531	172.26.0.32	172.26.0.32	2016-12-09 12:18:20.835249	2016-12-28 12:35:22.460948	John	Wu	吴炎强	1	2014-07-14	4	1	3	27	{"3bdQxblV0-8qKeM-mRYCdA":{"token":"$2a$10$TKHa4X/5kbQ7v5UJl2ihi.DVf/jDlPsunS4e1P8LIs6/awODQlj42","expiry":1484109322}}	email	jwu@xogrp.com	\N	1	      0      	User	22	1	\N
62	machen@xogrp.com	$2a$11$ISBvuY0P3AEuTP7sKOKRZ.LQ9jdrWUpx8C3YUELWaS7lcArrQ35qm	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.969478	2016-12-21 16:56:38.882706	Mandy	Chen	陈依曼	0	2015-01-19	12	3	33	5	{}	email	machen@xogrp.com	\N	1	       0        	User	7	1	\N
43	jozhang@xogrp.com	$2a$11$k/aV5uLMRarlOIuNVQEEyuvku8z.w6NrtOCGDoyVuTh8kiWRSmA0K	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.841949	2016-12-21 18:05:07.442388	Jomanda	Zhang	张蓓欣	0	2016-04-11	8	1	46	19	{}	email	jozhang@xogrp.com	\N	1	   0        	User	150	1	\N
37	janliu@xogrp.com	$2a$11$aKntM3JspdiwMIzz03VqGesKZmSrjree.nlU6ngvzJpYsO47wYnvC	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.801252	2016-12-21 16:16:29.293037	Janus	Liu	刘宇钧	1	2015-11-17	8	1	1	18	{}	email	janliu@xogrp.com	\N	1	       0     	User	38	1	\N
38	jay.huang@xogrp.com	$2a$11$BBVLeLPitRbrY2eYOthDsuCB0c3BO4FzIdqOZpR1K.jo9wDkq1iI.	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.807888	2016-12-21 16:19:25.929001	Jay	Huang	黄智勇	1	2010-08-16	3	1	8	18	{}	email	jay.huang@xogrp.com	\N	1	           0	User	111	1	\N
45	liuj@xogrp.com	$2a$11$NLJPOLifIhtcKSx96CxsQOaOflld17ABoR2onjPxT0tPnAnSHJyzS	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.85554	2016-12-21 16:30:30.137996	Judy	Liu	刘艳	0	2009-10-14	9	1	27	18	{}	email	liuj@xogrp.com	\N	1	     0    	User	38	1	\N
64	malin@xogrp.com	$2a$11$gQ.I.TB0ituqmTZoJKTz7OdM0Y2RZvkS9V2Og9aTRleXlIG8XFOI2	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.982887	2016-12-21 16:58:13.653228	Mayo	Lin	林艳梅	0	2016-03-22	8	5	35	10	{}	email	malin@xogrp.com	\N	1	   0             	User	83	1	\N
65	mmao@xogrp.com	$2a$11$rQymelE7IosStWYpNfVkN.GHLxyY1ukD1X1KOD2JBW3F6/jimc0Za	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.989623	2016-12-21 17:00:55.377987	Mike	Mao	毛东华	1	2013-08-01	8	1	5	11	{}	email	mmao@xogrp.com	\N	1	              0 	User	80	1	\N
69	owang@xogrp.com	$2a$11$.FtpkF1YDRh8Pjt908rS1Omuhk4sBDrFIALikP9B0vBAlJZKm2WkG	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.017106	2016-12-21 17:05:53.620358	Olaf	Wang	王槐庭	1	2015-09-29	12	1	15	13	{}	email	owang@xogrp.com	\N	0	\N	User	\N	1	\N
67	mzhao@xogrp.com	$2a$11$QMPZz/JAvGnbttltxhPhl..m0m6.wG6ztpnnPDivDWWoY8QXK9LU.	\N	\N	\N	1	2016-12-23 11:34:38.656562	2016-12-23 11:34:38.656562	172.26.10.133	172.26.10.133	2016-12-09 12:18:21.003309	2016-12-23 11:34:38.657884	Minnie	Zhao	赵婷婷	0	2015-04-28	2	4	14	7	{"C-vmaDjIxAHk4CuFaM0DQQ":{"token":"$2a$10$3ytEzjhVccaFWPOJjlBDjeGLbkTYaA8rA2KcMZ8hOQziJhYr7Lzs2","expiry":1483673678}}	email	mzhao@xogrp.com	\N	1	    0         	User	14	1	\N
105	yzhan@xogrp.com	$2a$11$r.dZmhPhurLXYhNzsaK0t.01Hpjchvq3lMqZNpKHZcW2CEGLnhS9W	\N	\N	\N	2	2016-12-29 10:10:35.341839	2016-12-23 12:33:06.323508	172.26.0.32	172.26.0.32	2016-12-09 12:18:21.269149	2016-12-29 10:10:35.343555	Yoyo	Zhan	湛碧瑶	0	2015-04-27	7	5	57	20	{"sv99iAfqsjortbDdmSTSmQ":{"token":"$2a$10$nf/IMUH3/Ckx9TP.WgalmuEwX68RTji19UHLmXlJVYlPw2HSsH1GG","expiry":1483677186},"mAuRH9ogOWqBHH0V8UY4Eg":{"token":"$2a$10$D6pfe4LXYZtAex/0TdIEGe3ytRVkld4ev01Alqli13.znLHV0erDO","expiry":1484187035}}	email	yzhan@xogrp.com	\N	1	10	User	83	1	\N
95	tliu@xogrp.com	$2a$11$yJZbtF6JnRf7QlClaxHmsOfpLX6hVcbihL8F6Kmgtvh6CkURtOOy2	\N	\N	\N	1	2016-12-29 14:43:46.697755	2016-12-29 14:43:46.697755	172.26.0.32	172.26.0.32	2016-12-09 12:18:21.200729	2016-12-29 14:43:46.69934	Tony	Liu	刘峰	1	2015-09-07	6	1	1	7	{"Ec18NSnzmnBRQjXhc5wTZA":{"token":"$2a$10$zypIAMxb3cYmaz/22mQVROSrieJVoeCNXt8.w3Ca5w4uo9qZ6mrPW","expiry":1484203426}}	email	tliu@xogrp.com	\N	1	02	User	107	1	\N
66	milai@xogrp.com	$2a$11$0A2PQoq4EQ7Iu392cWywWepqDVbSqaq2csQ3RaVswaXrj8MwEci5K	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:20.996379	2016-12-21 17:02:39.345453	Milly	Lai	赖晓敏	0	2015-03-30	4	5	61	16	{}	email	milai@xogrp.com	\N	1	   0            	User	63	1	\N
103	wgan@xogrp.com	$2a$11$uGiU2f5j0G4RVaAxVTbwpO94vvv.zazgyhGQIH4GAGs83k8TfN.pG	\N	\N	\N	1	2016-12-23 12:28:43.399986	2016-12-23 12:28:43.399986	172.26.0.32	172.26.0.32	2016-12-09 12:18:21.25557	2016-12-23 12:28:43.401312	William	Gan	甘卫卫	1	2011-10-08	11	1	1	11	{"8iEAHvn-pNrZrnWUJe6mYA":{"token":"$2a$10$vxozyOdZuMsuYgOlSReBsOHOaMeF.tzil5qpkPEIvkGwIt0UkK9me","expiry":1483676923}}	email	wgan@xogrp.com	\N	1	13	User	80	1	\N
97	trchen@xogrp.com	$2a$11$Ie2c7pRPVX76npvBFZQUAuLjIf8VI23WQHicuWJOBkacn0bNs2FDy	\N	\N	\N	1	2016-12-29 15:28:44.0395	2016-12-29 15:28:44.0395	172.26.0.17	172.26.0.17	2016-12-09 12:18:21.214159	2016-12-29 15:28:44.04081	Tricia	Chen	陈霞	0	2015-04-07	5	4	14	26	{"N1yiIFdmeoAG_5j34_jPRg":{"token":"$2a$10$pIFfCyQirV8KmtyeGw1lWu5W8x91JIMztwTfATJ9Gcf4Oh9a.2QjW","expiry":1484206124}}	email	trchen@xogrp.com	\N	1	04	User	14	1	\N
74	ryang@xogrp.com	$2a$11$6a0YEhUZxLUTXHuBvTvVrOE.CNeqThzTuuWYhP9BWp0T0bCVmFLUa	\N	\N	\N	1	2016-12-23 17:05:30.009953	2016-12-23 17:05:30.009953	172.26.9.87	172.26.9.87	2016-12-09 12:18:21.052668	2016-12-23 17:05:30.011248	Randy	Yang	杨瑞	1	2015-08-04	4	1	38	18	{"F8atypHqOUw8uPwre4roFA":{"token":"$2a$10$bMGrLwDVnoPa0ReTlXHnjuVMUwM58zHf/q0uBwxVTcpLHcwMlCMjK","expiry":1483693530}}	email	ryang@xogrp.com	\N	1	        0       	User	38	1	\N
98	tdeng@xogrp.com	$2a$11$bd3ws6yCuITTbWz8SA/Qo.Lfc7BVNJjlVAq2RHEdFJvpSfH9D4tjq	\N	\N	\N	2	2016-12-27 11:47:02.724448	2016-12-23 11:39:12.425788	172.26.0.17	172.26.0.17	2016-12-09 12:18:21.221962	2016-12-30 12:43:18.05286	Tyler	Deng	邓添华	1	2013-04-01	3	1	5	28	{}	email	tdeng@xogrp.com	\N	1	05	User	8	1	\N
145	leli@xogrp.com	$2a$11$BqtTH0c/Detz19jhdK4EfOoPe3v3Xqc29NeuDiIuJZWlDhFV/8Nzy	\N	\N	\N	1	2016-12-30 10:57:05.594911	2016-12-30 10:57:05.594911	172.26.0.32	172.26.0.32	2016-12-21 16:47:44.576939	2016-12-30 10:57:05.596271	Leo	Li	黎兆滨	1	2016-08-01	7	4	31	27	{"-_5nC-5Es6ZPbutyXG0R8w":{"token":"$2a$10$a08X4P05OODcOEFukx4Rvu/zAjDSUgE2ASREe9cId8oZ17Wjt0axu","expiry":1484276225}}	email	leli@xogrp.com	\N	1	     0        	User	14	1	\N
88	stchen@xogrp.com	$2a$11$7mzM9HxDa7u37Jx2dPRcKOzmVglAizZ0QikNAm5nUtLIq6eSbp7Km	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.153876	2016-12-09 12:18:21.153876	Steve	Chen	陈顺利	1	2015-09-07	4	1	15	11	{}	email	stchen@xogrp.com	\N	1	\N	User	\N	1	\N
72	pichen@xogrp.com	$2a$11$UGOS1s5m8PUxbZGdz.FvDOBOR7Y6MvIFHWWI41Kp2uybScqmnBMYy	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.038547	2016-12-21 17:09:20.200945	Piano	Chen	陈淑琴	0	2014-09-10	6	1	37	19	{}	email	pichen@xogrp.com	\N	0	\N	User	\N	1	\N
75	raychen@xogrp.com	$2a$11$vFbxc5NIWoeu3YmChrHB3ewnsYPif4bYHR7RjW3nkImBydJLFFuHG	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.059834	2016-12-21 17:11:43.933922	Raymond	Chen	陈伟杰	1	2014-11-10	1	6	22	22	{}	email	raychen@xogrp.com	\N	0	\N	User	\N	1	\N
76	rali@xogrp.com	$2a$11$PCzfo6UROvz6fvRawAdZueJHut68zUReBioUjrVCBKLXjiu7UOulu	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.067087	2016-12-21 17:12:36.942326	Raymond	Li	李铭航	1	2016-02-15	5	7	39	7	{}	email	rali@xogrp.com	\N	1	            0 	User	111	1	\N
77	rcai@xogrp.com	$2a$11$nZNTzf4rlJCRZ5vRQUWzJexjV7r.xe3hauAMpuRJFQt6GHpa8zhIu	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.079347	2016-12-21 17:13:47.484279	Richard	Cai	蔡念华	1	2010-05-04	7	1	17	26	{}	email	rcai@xogrp.com	\N	1	      0            	User	8	1	\N
80	shu@xogrp.com	$2a$11$iDUT2PHAWxX.pfkHkE08mOp7BmTjDSiDqDY3vOKyZexf4RABhRLnu	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.099567	2016-12-21 17:16:28.027431	Samson	Hu	胡晓辉	1	2015-06-08	3	1	8	11	{}	email	shu@xogrp.com	\N	1	      0                	User	111	1	\N
81	schen@xogrp.com	$2a$11$uqBrILrc9aBhOTJRha0yDe2ArBszkTcIxoWDHIahXVibjLFO5lz1u	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.10629	2016-12-21 17:17:17.409391	Sany	Chen	陈泽燕	0	2015-06-01	4	1	15	8	{}	email	schen@xogrp.com	\N	1	      0              	User	8	1	\N
82	sliu@xogrp.com	$2a$11$vvLKNyedC.tFDxKtHoS5Ae8bQMHmY4xLsB/hcIgUBKNGgM/8paif2	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.113152	2016-12-21 17:18:18.736478	Sarah	Liu	刘亚玲	0	2014-06-03	9	1	3	27	{}	email	sliu@xogrp.com	\N	1	        0          	User	22	1	\N
86	sophiah@xogrp.com	$2a$11$WRd91Dck1/om796YjFa9x..TtLetCq7trZRp256Ny5ERjwjh4NfSS	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.13988	2016-12-21 17:24:44.071408	Sophia	Huang	黄淑静	0	2013-12-19	6	5	42	16	{}	email	sophiah@xogrp.com	\N	1	      0               	User	63	1	\N
89	smo@xogrp.com	$2a$11$KKNT.oE03tYlMlpXmt57.eKkzNZajRBmIH.icVUhqzugoa6U/bw1q	\N	\N	\N	1	2016-12-20 11:06:37.596114	2016-12-20 11:06:37.596114	172.26.0.32	172.26.0.32	2016-12-09 12:18:21.160503	2016-12-21 17:25:30.510453	Sue	Mo	莫淑群	0	2016-01-04	1	1	44	27	{"iR9k75u3WjR1jdK3xHY7Xw":{"token":"$2a$10$XF861Fb0G9qdlVoCFNPlbejKNt/PuQg/EAwN.7o9Je09.bApgftIS","expiry":1483412797}}	email	smo@xogrp.com	\N	1	           0          	User	110	1	\N
92	ttao@xogrp.com	$2a$11$E6vjuYp/kv7qpxM03HkrA.NNDv8ntVXtRqoJJ5rBkEkt86kn5gbKu	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.180777	2016-12-21 17:30:02.441648	Taurin	Tao	陶建	1	2015-10-08	3	1	44	3	{}	email	ttao@xogrp.com	\N	0	\N	User	\N	1	\N
94	tizeng@xogrp.com	$2a$11$YlylUX8TrGdXWz5kN.W1C./6lBoysPQp.rI4DPz66q1f4dKTkHcSm	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.194103	2016-12-21 17:43:05.162285	Tina	Zeng	曾桃	0	2015-03-24	12	4	14	11	{}	email	tizeng@xogrp.com	\N	1	01	User	34	1	\N
99	tychen@xogrp.com	$2a$11$/fKxGSt.wV4WsDifcap1tecRettND1zpClJLNCgK8kqJUuXVymJdm	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.228826	2016-12-21 17:47:55.997193	Tyro	Chen	陈嘉辉	1	2015-05-13	11	1	15	18	{}	email	tychen@xogrp.com	\N	1	06	User	38	1	\N
104	yli@xogrp.com	$2a$11$AdzXtqiaZ.TiSyBB/DZM0ePJ/kgGznAqhLb0aid47knP8ADrTE3RC	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.262403	2016-12-21 17:52:41.61457	Yan	Li	李嘉焱	0	2013-09-23	7	5	46	16	{}	email	yli@xogrp.com	\N	1	11	User	63	1	\N
102	wlao@xogrp.com	$2a$11$yn3TR5/bznDtwuf8JdPU1e5xYcoedcaX7.SfERBTp9Zwnl3IJOEV.	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.248961	2016-12-21 17:54:01.918094	Will	Lao	劳湛成	1	2015-06-15	7	7	3	27	{}	email	wlao@xogrp.com	\N	1	14	User	\N	1	\N
148	scyang@xogrp.com	$2a$11$H4iBs/ybs4dc0vGv4RG8qOm8fb5E7iQ4bCa73EYdJWlM9rQ0mdZ3G	\N	\N	\N	0	\N	\N	\N	\N	2016-12-21 17:22:23.138826	2016-12-21 18:06:44.094623	Scott	Yang	杨全耀	1	2016-09-01	2	1	15	7	{}	email	scyang@xogrp.com	\N	1	           0 	User	107	1	\N
93	tli@xogrp.com	$2a$11$.paYM4oQ6U4pzsYlXmtIOOAZxTOahd8pxF.dtiCBkBOlNTvvZiihG	\N	\N	\N	1	2016-12-23 11:31:11.840519	2016-12-23 11:31:11.840519	172.26.0.142	172.26.0.142	2016-12-09 12:18:21.187439	2016-12-23 11:31:11.841851	Thomas	Li	李秋旻	1	2009-08-03	10	6	16	27	{"rq2PpvgE8-nVjjrUP8mKMg":{"token":"$2a$10$uT5T93X.mffOeATRn7Jewuc8tNhM6AXro.nhI2N3YMXxU2HfigQp2","expiry":1483673471}}	email	tli@xogrp.com	\N	1	1212	User	111	1	\N
147	mcduan@xogrp.com	$2a$11$CryQCj.bR/qHsgmG6WC5XefsIylW07QdWqcDZynWUZzg2x8unb/qC	\N	\N	\N	1	2016-12-23 11:39:30.069087	2016-12-23 11:39:30.069087	172.26.0.17	172.26.0.17	2016-12-21 17:00:04.791282	2016-12-23 11:39:30.07054	McGrady	Duan	段一凡	1	2016-10-26	10	1	3	27	{"nH5I8Z6wRMWr5zN8yxfz-w":{"token":"$2a$10$H9wy3RH5lT3l2wkqu7FbL.R.JGaXGOLymJYbK4U6z6Xrkz1DNMJzi","expiry":1483673970}}	email	mcduan@xogrp.com	\N	1	 0             	User	22	1	\N
90	suli@xogrp.com	$2a$11$FabSGBVllR0AXj38dpU8muWBY1wPlgUSuYr96EDp6gUfPXyEvvwLO	\N	\N	\N	11	2016-12-29 16:06:31.782447	2016-12-28 16:41:03.093275	172.26.0.17	172.26.0.17	2016-12-09 12:18:21.16731	2016-12-29 16:06:31.78438	Suki	Lee	李建清	0	2011-10-08	1	6	16	18	{"lnAmO0AOg-Pr3sHdwLpaFA":{"token":"$2a$10$mPkBU3NcVFs4YAdpcBqrbO/HAY5ASLC6Q6QssanON3UO855h1fU5.","expiry":1483066763},"M2e57SVCU5fSAJfhaQplVw":{"token":"$2a$10$iPT68fPcLnrba8Jl/qsCJe1C79164lXE4KVNeJB0CLT1Y7n1lC3t6","expiry":1483427037},"mUCda3oRYTNHKxmEoQhB4Q":{"token":"$2a$10$kp2FLqy8NPYNZQAWaqC75.nxvGwINumYFgCnVsFCZKPIYeMsVXygi","expiry":1483507642},"f37z2BLA7c9GyO9uFSCh3w":{"token":"$2a$10$P3o13QB9/DfdmGA6WiGDheCMbNSmtT5Zn8lPwZU7/ojuCCp28oQsS","expiry":1484208391}}	email	suli@xogrp.com	\N	1	440684	Owner	111	1	\N
117	reviewer4@test.com	$2a$11$giEOvUXxvq3gtwHoJQFKx.MHfNYu3pLlinRr/p4zK5yO7VWoGalZu	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 18:45:04.055988	2016-12-13 18:38:00.972007	reviewer4	reviewer4	reviewer4	0	2016-12-09	1	4	31	\N	{}	email	reviewer4@test.com	\N	0	1234	User	\N	1	\N
58	llai@xogrp.com	$2a$11$vSFu3J.LRyJUM4TMkbikxuOUahAxvvyFRkWbCsLNUzhVea8JAODLu	\N	\N	\N	4	2016-12-20 14:58:48.872717	2016-12-12 11:16:01.848195	172.26.0.17	172.26.0.17	2016-12-09 12:18:20.94246	2016-12-21 16:53:47.617789	Lucas	Lai	赖正福	1	2010-03-15	5	1	5	26	{"HPRAjI42XHOlTewJxOipTw":{"token":"$2a$10$0w7sl3F1VgNsm2x7P3mhp.tYrCtlZnghI3EQXh6x4a/41Zh4xee2y","expiry":1483426728}}	email	llai@xogrp.com	\N	1	       0       	User	8	1	\N
144	lliang@xogrp.com	$2a$11$BuTYFDm28BHzdWQPnmDVreH.lJ795ZLBdAHn604TIUq2H08yEr2Ha	\N	\N	\N	1	2016-12-23 11:53:25.425838	2016-12-23 11:53:25.425838	172.26.0.17	172.26.0.17	2016-12-21 16:44:25.940507	2016-12-23 11:53:25.427234	Lana	Liang	梁泳仪	0	2016-08-10	11	1	46	19	{"zfBbHBQ-V4TGNuDtylTuXA":{"token":"$2a$10$pXYtgAkYYrV70kSOthObQOEPe6JsD.ylKTXd/5WOMOB1oXrmRRRYe","expiry":1483674805}}	email	lliang@xogrp.com	\N	1	    0       	User	150	1	\N
53	lewu@xogrp.com	$2a$11$GWu05Gz.0zU2IknpXtT3f.qUAv9lbcn3uvrLw4FzfPk1p7JYq7rzW	\N	\N	\N	1	2016-12-23 11:25:14.186241	2016-12-23 11:25:14.186241	172.26.0.17	172.26.0.17	2016-12-09 12:18:20.908867	2016-12-23 11:25:14.18772	Lenna	Wu	吴秋蕾	0	2015-06-01	9	4	14	7	{"2XH5_D-Oc41h3kvvTYcF3g":{"token":"$2a$10$US75H9Q/TkUlEE2VyqoQyufXq9Q2eSy.oDEGINy981uxRB5TvH8Dm","expiry":1483673114}}	email	lewu@xogrp.com	\N	1	      0          	User	14	1	\N
96	tinxu@xogrp.com	$2a$11$nBM6D5zdiKXA1ts3gnOBrercPHFH5pndk1uRssRJNqAP9lY.3RlHO	\N	\N	\N	3	2016-12-30 11:38:02.988584	2016-12-22 18:16:15.060939	172.26.0.32	172.26.0.32	2016-12-09 12:18:21.20737	2016-12-30 11:38:02.990563	Tracy	Xu	许婷婷	0	2015-01-05	6	6	43	11	{"piN8KqQFY7vTGtklfaDVLA":{"token":"$2a$10$ptzmTkdhtyHkvh8nM2EqJOAQ8ViI2Vm/chKMHfJM1PTd5xy4pHcra","expiry":1483340078},"eGaUIB4obyGVDpNjP_egOw":{"token":"$2a$10$vRPKBoocmqdR1UyIE9GwkeOK6fNkK5aAJ7yyfVBzahP4lept0rdlG","expiry":1483611375},"nbzIw__xe30wSXVaRM-TFg":{"token":"$2a$10$4J3HCZaOteTBq8EUZ6jEFeERf7/FuaP0CPD1k8hLoOAMpjKPtXeYm","expiry":1484278682}}	email	tinxu@xogrp.com	\N	1	03	User	111	1	\N
111	pchan@xogrp.com	$2a$11$cHaEpPFHdnE9r5prm9NM9OQL3Lsk20OjtsUqmLH8Svt20OS30SBce	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.309692	2016-12-21 17:08:07.93618	Philip	Chan	Philip Chan	1	2011-12-06	11	8	50	25	{}	email	pchan@xogrp.com	\N	1	         0      	Admin	\N	1	\N
84	seli@xogrp.com	$2a$11$ZUo81sf6bOFxSQsPxkLiT.g4cahkkujs2xgaXUEzVVYueanhySdvW	\N	\N	\N	1	2016-12-27 10:22:03.321643	2016-12-27 10:22:03.321643	172.26.0.32	172.26.0.32	2016-12-09 12:18:21.126647	2016-12-27 10:22:03.32314	Selina	Li	李芳琪	0	2015-10-22	10	4	14	11	{"QBSicTB43cQFeljeI_gQ-g":{"token":"$2a$10$Zq2WKRuWcrAB1XVFhqbJhennGB44fOEMFmo6XxRydjUHuZqn5mGV.","expiry":1484014923}}	email	seli@xogrp.com	\N	1	       0          	User	14	1	\N
149	susun@xogrp.com	$2a$11$FWQGbD7MFaLOuvJaDtdPDOWiNOSbpY0wkPVax3zgBfBPzrhM48bjO	\N	\N	\N	0	\N	\N	\N	\N	2016-12-21 17:28:40.336215	2016-12-21 17:28:40.336215	Sunny	Sun	孙立志	0	2016-09-19	2	4	14	28	{}	email	susun@xogrp.com	\N	1	121	User	14	1	\N
110	angan@xogrp.com	$2a$11$Dy4oYFc1ij35dLvMT7LYzu7dYxXufAsA5umT2AqQVAFoc/T7u4w9m	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.30292	2016-12-21 14:57:08.72649	Anson	Ngan	Anson Ngan	1	2009-09-07	6	8	49	25	{}	email	angan@xogrp.com	\N	1	0     	Admin	\N	1	\N
113	reviewee@test.com	$2a$11$/l5Y4xaC2vg11b1TxwH7p.nEW9VEJhIt1vtvUzsTpwa5xM94xLztq	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.323283	2016-12-21 17:30:04.762653	Test	Reviewee	测试被评估者	1	2015-01-01	1	4	14	9	{}	email	reviewee@test.com	\N	0	123	User	\N	1	\N
114	reviewer1@test.com	$2a$11$NhRUgB3rO9skFR.Pb6vUYOrqdJiv4sljDgCIKsPok1h3.jqO8r5.e	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.329933	2016-12-21 17:30:06.42829	Test	Reviewer1	测试评估者1	0	2015-01-02	2	4	21	9	{}	email	reviewer1@test.com	\N	0	\N	User	\N	1	\N
115	reviewer2@test.com	$2a$11$WuyJOvqFwlSUIQDjfq6XHOPH8SgXMWpWAR7y74i7Eg.cX2vtgvKlm	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.336606	2016-12-21 17:30:08.240329	Test	Reviewer2	测试评估者2	0	2015-01-03	3	4	9	9	{}	email	reviewer2@test.com	\N	0	\N	User	\N	1	\N
112	dwong@xogrp.com	$2a$11$P35gM4OYcK85V8guQ9LAvedg2IaI2NC0mlDn1bxAhVAwUPQsL8co2	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.316447	2016-12-21 15:39:14.136817	Daniel	Wong	Daniel Wong	1	2009-06-22	5	8	51	25	{}	email	dwong@xogrp.com	\N	1	   0   	Admin	\N	1	\N
108	eyu@xogrp.com	$2a$11$1jElTViGPW1PhEvvNz84MOVSkjIpIQ6h2iuACzvUgOYNZwBDgU/JG	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.289642	2016-12-21 15:52:30.516125	Eric	Yu	Eric Yu	1	2016-03-01	1	1	5	27	{}	email	eyu@xogrp.com	\N	1	       0  	User	110	1	\N
116	reviewer3@test.com	$2a$11$qzgBrBGxUDjNcqkZW.P4/OyUYVutpAFvYkJbb34yzrFK1JpFws2E6	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.343389	2016-12-21 17:30:11.5666	Test	Reviewer3	测试评估者3	1	2015-01-04	4	4	13	9	{}	email	reviewer3@test.com	\N	0	0	User	\N	1	\N
106	yuli@xogrp.com	$2a$11$n9rcSmWet7coQoTYYQvgmuZnSBkjdZqsf6NQC3bZc8y3DyOKqxe9u	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.276025	2016-12-21 17:51:25.461339	Yuki	Li	李迅迅	0	2015-04-20	10	5	30	16	{}	email	yuli@xogrp.com	\N	1	09	User	63	1	\N
107	nwu@xogrp.com	$2a$11$Xbpz7ytrHDlbWXOGcLANiurUzmjGh18NCv04LJatUgvXbz/2qr8ma	\N	\N	\N	1	2016-12-22 17:56:14.938019	2016-12-22 17:56:14.938019	172.26.0.32	172.26.0.32	2016-12-09 12:18:21.282896	2016-12-22 17:56:14.939399	Nick	Wu	吴宇凡	1	2016-07-18	11	1	17	7	{"FHgeiKMy-lhEGhY9-jcr-g":{"token":"$2a$10$JE7G/5is/7/0T6Zs2j4dfuBr67av24PIXTdO31u.ujbhrQM5KJpcG","expiry":1483610174}}	email	nwu@xogrp.com	\N	1	         0       	User	111	1	\N
28	gzhang@xogrp.com	$2a$11$doehvmVOVJxKUdSBpDbkau7IPbqvKvzLYACb1f23XJ89QVDdx5YHG	\N	\N	\N	2	2016-12-28 10:25:51.865163	2016-12-23 11:42:18.113004	172.26.9.92	172.26.0.17	2016-12-09 12:18:20.740773	2016-12-28 10:25:51.866874	Gabriel	Zhang	张耀明	1	2015-01-30	1	1	1	11	{"uZEVfIZvSGCaXt8xmSM5EA":{"token":"$2a$10$hQZ4enMMQw99Z2tE3eRnNeK4kCNkNWJbB26m1rDX1g74mKX0nrd5O","expiry":1483674138},"9MUTI0GyDef2GvpqbFsKSA":{"token":"$2a$10$pHqCACjUgnVkmm4sp/fB.OIw5tYzdmLkle8itfn3D3Wqa3kgd5Me.","expiry":1484101551}}	email	gzhang@xogrp.com	\N	1	    0  	User	80	1	\N
55	liwu@xogrp.com	$2a$11$s48pSEMQKjeKL7IwucERJOc0FYDv6jZR0qVX3SJLo4wmrlC4jeAsq	\N	\N	\N	2	2016-12-28 10:38:53.762806	2016-12-09 17:46:21.158207	172.26.0.17	172.26.0.17	2016-12-09 12:18:20.922293	2016-12-28 10:38:53.76448	Lina	Wu	吴丹丽	0	2016-02-24	10	4	31	27	{"jQzIuSqW70Tiq9KZrBjX0A":{"token":"$2a$10$XBzq80fTFr/kd8Iffuw2hO6NpmH8DcxFsOFKv13stmB5LXVQj.wee","expiry":1484102333}}	email	liwu@xogrp.com	\N	1	       0           	User	14	1	\N
71	pliu@xogrp.com	$2a$11$08hhNiQO1DCmCZSBEDGfZe7Nl3MgGd2z619VHCBBVcE/lM76p/BVi	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.031407	2016-12-21 17:08:55.970911	Phoebe	Liu	刘楚荧	0	2015-05-27	12	5	35	10	{}	email	pliu@xogrp.com	\N	1	       0      	User	83	1	\N
118	reviewer5@test.com	$2a$11$1EkgkWlzAOXVX1q/7sMOCurIvbeeBxTByq00kbFStI14nkQWiyubq	\N	\N	\N	0	\N	\N	\N	\N	2016-12-13 18:39:12.559464	2016-12-21 17:12:49.356217	reviewer5	reviewer5		0	2016-12-13	1	1	1	\N	{}	email	reviewer5@test.com	\N	0	12345	User	\N	2	\N
85	szhou@xogrp.com	$2a$11$WQqVYjYBfa3vwz5Tad89C.Jb.MYnRD6CtKQ1UoMIVQQC/o2ht5OwW	\N	\N	\N	0	\N	\N	\N	\N	2016-12-09 12:18:21.133251	2016-12-21 17:23:26.640969	Shawn	Zhou	周小登	1	2013-07-01	8	1	1	22	{}	email	szhou@xogrp.com	\N	0	\N	User	\N	1	\N
139	jehuang@xogrp.com	$2a$11$lODQxppelyWAhsvSm7fclOWiYEnbKvvC8JaAM3wH1UJEGIWeIxAb.	\N	\N	\N	1	2016-12-23 11:42:39.235371	2016-12-23 11:42:39.235371	172.26.0.17	172.26.0.17	2016-12-21 16:20:53.43877	2016-12-23 11:42:39.236704	Jeffery	Huang	黄振辉	1	2016-10-26	4	1	54	27	{"Wpo2elA3WgwxZ9ns2-3MCA":{"token":"$2a$10$nsKQoy.msGL6OzEpHu2QP.uGO//gkK/sVjKQ4iTXUA/s/GaDgirT2","expiry":1483674159}}	email	jehuang@xogrp.com	\N	1	        0	User	22	1	\N
79	rzheng@xogrp.com	$2a$11$rOVM3hTLK62Te41ev7Mx6ee9OqCeTlZ5VU7rpAJQEgapR4Xy8oNDS	\N	\N	\N	10	2016-12-19 17:34:21.58029	2016-12-16 11:02:04.746371	172.26.0.32	172.26.0.32	2016-12-09 12:18:21.09289	2016-12-29 14:39:49.998638	Roy	Zheng	郑少东	1	2013-06-13	8	1	1	18	{"wdHvyroS24kr1BhQxDeGGw":{"token":"$2a$10$fC8yblLTh0wT8MT4360b3OBCjRuKljO6RM39CC.DxfDfSDpeT5Naa","expiry":1483066924},"ZYNYvNcHCCHsogp3C58Dmw":{"token":"$2a$10$ZJ8HwYSOPkJFImytLDL99ubat35oLAjM/rqmwc8lsLuVT5M9vBhEe","expiry":1483349661}}	email	rzheng@xogrp.com	\N	1	       0         	Owner	38	1	\N
3	alliu@xogrp.com	$2a$11$eDFB7Rhokc5eO0O4SVn3CuvMvZ6YxQikMpiekiOQzEwNIDx9dfd3i	\N	\N	\N	2	2016-12-28 12:31:37.385078	2016-12-22 17:49:17.194148	172.26.0.17	172.26.0.17	2016-12-09 12:18:20.534719	2016-12-28 12:31:37.38693	Albert	Liu	刘光泊	1	2014-11-11	6	1	3	27	{"ualn762vq2Q23mSIJ8oTSA":{"token":"$2a$10$xfnbszpiFqT.UkBaZp6Fzuryam3qqDL.1Sx13LiL99BTBA7sx/Pxu","expiry":1483609757},"DPUoQyDYp6hlJ92PJYfADA":{"token":"$2a$10$/CyranRFGF/XjzoaLMtGi.bvjvh17wI3LqrTFHlyUo.n9IMTjR.bi","expiry":1484109097}}	email	alliu@xogrp.com	\N	1	0   	User	22	1	\N
12	bzhang@xogrp.com	$2a$11$YtOdcAly2s/LVDnzZAW2XuHXSiyJU8rVK7X65UhddiZcxErFBmhme	\N	\N	\N	3	2016-12-30 10:11:51.545571	2016-12-27 16:05:10.650274	172.26.0.32	172.26.0.32	2016-12-09 12:18:20.607173	2016-12-30 10:11:51.54753	Bill	Zhang	张业弘	1	2016-06-06	2	5	12	10	{"itvT6ITIEmCABADaexFGQQ":{"token":"$2a$10$R14oC23A3aO0NGqHqR14tOYT8gCgT8KpNatNmSd5Mj/92579gUByu","expiry":1483612374},"DILBH6JCDhaV3CkzSCkRBA":{"token":"$2a$10$M5zJUx2FEruu//vNaRM8Y.vFB.WmhQ5UziFkAocipjDU9/3vZyJ/2","expiry":1484035510},"ojghWKLl3aU7fxzwvDJ3yA":{"token":"$2a$10$upK1QWZjIqZjbCu.mT88BeXhktIuVVNN/wxIeuEbNKndR19cQ5bxm","expiry":1484273511}}	email	bzhang@xogrp.com	\N	1	    0 	User	83	1	\N
70	olin@xogrp.com	$2a$11$1ZQM8GK6XLIr7m4XgpG5fupHxKiOr/czpxnJIov5tqg5ZlQz2jopq	\N	\N	\N	1	2016-12-23 11:47:46.184473	2016-12-23 11:47:46.184473	172.26.0.17	172.26.0.17	2016-12-09 12:18:21.024256	2016-12-23 11:47:46.186165	Oliver	Lin	林江煌	1	2016-05-30	2	1	15	18	{"Mkt6ZrJZjiflhsOrvrmp-A":{"token":"$2a$10$ZXXzwOC2zAYz95zhQo8DzeDKqhea7MKnmtM54U1CavVMGSHL7Ssui","expiry":1483674466}}	email	olin@xogrp.com	\N	1	        0 	User	38	1	\N
29	gxu@xogrp.com	$2a$11$OkRG1IpydbkHPDoOgsixOOJdVwcko7pj1lwl4fGg2dDk2NF.HVglO	\N	\N	\N	5	2016-12-29 17:42:29.142756	2016-12-29 16:32:02.155867	172.26.9.123	172.26.9.123	2016-12-09 12:18:20.747626	2016-12-29 17:42:29.144632	Gwen	Xu	徐榕芬	0	2016-05-03	9	5	12	10	{"RNSjE7l7leRpXQUh6Yb77A":{"token":"$2a$10$7zC/G.J6peG27k3Mg3Vy3OoW9SnzG9Uk5PVv.Dgr9bZXirMOuenMW","expiry":1483674698},"ndQd02YzU8LHP3eszv6hRw":{"token":"$2a$10$MYCJN9HJjahX80jHNaV.l.zoL8jJ3zLEV4liCa0Q8F2ifg/o32c96","expiry":1483696042},"Qhq2COUGUyX88dlNCTF_eQ":{"token":"$2a$10$ddPpPc7VY2ZMUTqGyp1MNeV.nZ/Emre9pT35b7EYF2OXtdjvOXuh2","expiry":1484042375},"QMPbLdX-08yCo2DZDMav_w":{"token":"$2a$10$SJyDKUTxLYWrzjfmcuR3I.KHcOo/Bsbmz8Jup/KdQ.dCl7IuxPEn6","expiry":1484209922},"o7TFbPwOdogBJz2KTcrdYA":{"token":"$2a$10$cpy6dzfYXvojq/yD8r9ywuNS9Gf.sbYB3IIuLTwaqDzIPA.bsKHGK","expiry":1484214149}}	email	gxu@xogrp.com	\N	1	 0    	User	83	1	\N
91	sgu@xogrp.com	$2a$11$AyjeSIcqV94fp2333JBFCe/HzVm6TGdbb4V7Oq3DOlV2cZFn3ugI.	\N	\N	\N	1	2016-12-23 11:49:34.378245	2016-12-23 11:49:34.378245	172.26.0.17	172.26.0.17	2016-12-09 12:18:21.174135	2016-12-23 11:49:34.379611	Syvia	Gu	古硕颖	0	2016-05-09	4	5	12	10	{"tr8_kFTfw_4kF6616-HgwQ":{"token":"$2a$10$OyaSI2/jysIzLCX5q9VHlunJSjwWoY7ZBlHMGB7pRDVEYFI9Bmi/m","expiry":1483674574}}	email	sgu@xogrp.com	\N	1	12	User	83	1	\N
47	klin@xogrp.com	$2a$11$8ZSvncUe4KL/hCjqeuyArO2ew6jD6cskZ77EnhSZR7eWpjTa8iRPK	\N	\N	\N	5	2016-12-30 14:21:01.02404	2016-12-28 17:46:33.513804	172.26.0.32	172.26.0.32	2016-12-09 12:18:20.868852	2016-12-30 14:21:01.02605	Kelly	Lin	林海娟	0	2015-07-15	10	6	60	27	{"1W8X7UJyxWVVYTh6daWRWw":{"token":"$2a$10$V4x8PuK9YcO0Me719GuJOe0yiPOFz5.b.1edqjjjAaieXo8ZsMioK","expiry":1483412479},"AEgQRexsKgL_q__9OeFrjQ":{"token":"$2a$10$1bDJVdRP6SD/9ym6QliawerPXYpLaw6WrBLujdJNsN.90IUcXjxfW","expiry":1483673438},"k3QHAiGoV9PbfLkH-OqOzA":{"token":"$2a$10$b9wXwESDqrS2CzsVfSOXUOTBe/4QSSEdYmwZXjutDLIHrGJaH0Ph2","expiry":1484124237},"PQrbJtRMbT8pt6WFsawqBQ":{"token":"$2a$10$QSDentLXfzwhi5rhrnAAbeaSmqbROkpFhkVihsDhbed9HBGq67Cna","expiry":1484127993},"_9jHVsQWpyNstG-Cf22NnQ":{"token":"$2a$10$FcMFwfXnvWjFCo6yS.0ge.QmJkVD09hGJdroQo4rmXLlIX9YWC.EW","expiry":1484288461}}	email	klin@xogrp.com	\N	1	   0          	User	111	1	\N
52	simonlee@xogrp.com	$2a$11$Wst1MMDw2fh6S9sGNLXFEO5Dx35EBjk6Z/HENysNgHw3Be1n8RkU2	\N	\N	\N	2	2016-12-28 09:52:09.012342	2016-12-20 11:12:45.818146	172.26.0.17	172.26.0.17	2016-12-09 12:18:20.902212	2016-12-28 09:52:09.014291	Simon	Lee	李达华	1	2011-11-07	7	1	10	27	{"sfzF-2pYOogDwZJDMpPpJw":{"token":"$2a$10$r9Rgm.B/qugYDbW3RFHmKOqOOhaeOeltq.2FJ32pDpLFx3TGfrzL.","expiry":1483413165},"dfNvq4OJmqVCPrIjv39o2Q":{"token":"$2a$10$i3ERTIW/2cpmRUsqA2fEueccbjE2MLLztqvQgpGvWH7g26r2mcv7q","expiry":1484099529}}	email	simonlee@xogrp.com	\N	1	       0            	User	22	1	\N
68	nfeng@xogrp.com	$2a$11$ZQcG5VHqHlQhzskxQMAmEeFP0Q9lkcMaQvQEGCdZmbdsOhGyOMcGO	\N	\N	\N	6	2016-12-23 16:47:34.507901	2016-12-19 15:07:45.550817	172.26.9.48	172.26.0.32	2016-12-09 12:18:21.010137	2016-12-23 16:47:34.5098	Nancy	Feng	冯淑雯	0	2013-03-07	7	3	36	4	{"W3S1J9_yqoqOLdOVKHB4JQ":{"token":"$2a$10$KaFsTdaynDC6DPXP59N1ieCXbpd6Pdf9LF8YGw.sKqSiITCTwPVoS","expiry":1482905988},"4G_t9RG3fd81DDw0G_wIig":{"token":"$2a$10$qYg4RtM2yU9RG.zDTcx7TuiGbFGjrFvXF7l99uOQXKGL40NqZipSS","expiry":1482906048},"mSUn5tIQM6M9bBJC15PXGA":{"token":"$2a$10$FqbSLogR7QwCrOanxy8OiO5gdBZrvBGhQVa9nkNnfMyKeV9aCgRTa","expiry":1482906073},"XD1q9HWbURQdXPGn26yo4A":{"token":"$2a$10$SUc9MCi.5vWzQy.pAIemHuvi4pt0zB7XnMKIo2wvwLxw1yrjLe5de","expiry":1482906153},"4YmC0I-1sIfWBuM1S9l7hw":{"token":"$2a$10$d5D3IWpdOg.hfTxiS1fHgu8AiQN7jel78qpXGcoOWQXiWtwWkwULS","expiry":1483340865},"qs-j9_1R0_UdkzoKyQZL-Q":{"token":"$2a$10$SKHZxBGgfDI4rAf05aD8qOfHO8yK88j2d6fD6MA3P72JmNcc0bFty","expiry":1483692454}}	email	nfeng@xogrp.com	\N	1	   0           	Admin	109	1	\N
73	pxu@xogrp.com	$2a$11$EHkxshiUhgyf4pVq7LAMnOXWsp5pvFND9LdmRdvfHvKtNTOtvMgzO	\N	\N	\N	2	2016-12-20 15:24:42.714164	2016-12-13 14:44:06.060803	172.26.9.156	172.26.9.156	2016-12-09 12:18:21.045651	2016-12-21 17:10:38.700601	Purity	Xu	许敏仪	0	2016-04-25	11	6	22	18	{"Q5Qcn8KKE9vAg17TOflfHA":{"token":"$2a$10$AlFS4BZ0Mn1LozF8SY4T8e4nSRRWej48wVOvyPr8OYYlPeeRw78ya","expiry":1482821046},"HneyC9nB0F12Ibpd-c0xHQ":{"token":"$2a$10$hnbX9sFphoxw3IfiSPm/i.DBxjPUxUr/fscLNMHKsHXp8a4HAr5yG","expiry":1483428282}}	email	pxu@xogrp.com	\N	1	   0              	User	111	1	\N
143	lazhang@xogrp.com	$2a$11$eI1PzhbdMYxM38or30qk0uB3pyaEkkzV9.lS00D4twCPRNXqXifp6	\N	\N	\N	1	2016-12-27 15:31:56.96208	2016-12-27 15:31:56.96208	172.26.0.32	172.26.0.32	2016-12-21 16:42:34.612706	2016-12-27 15:31:56.963518	Lala	Zhang	张慧娜	0	2016-10-10	6	6	22	26	{"3qP-8ffQALL9NBdWzNInZQ":{"token":"$2a$10$wqcXtryzHoKD7fl2HdmuT.GgufpNSwE.SFxO2tP.wvB1ZJrodtWXS","expiry":1484033516}}	email	lazhang@xogrp.com	\N	1	    0      	User	111	1	\N
137	jazhang@xogrp.com	$2a$11$PX6WrFF1QtbR7vDhoYV9ZeOMpTos5pzYqgTbpSPMq38LnK5VQvPcW	\N	\N	\N	2	2016-12-27 20:42:30.928161	2016-12-23 11:38:04.281811	172.18.64.44	172.26.9.164	2016-12-21 16:15:01.421677	2016-12-27 20:42:30.929915	Jacky	Zhang	张业生	1	2016-10-17	10	1	15	11	{"ZSqNk5uXS5gUqP4ligM9ag":{"token":"$2a$10$DNdwzxptCS/OnZioBMPGeObhsofdiNZizvd8qt0Wb88CksZEm/y12","expiry":1483673884},"LtPomKgZkkGVg-IB8lZEvw":{"token":"$2a$10$0eSoVi8rxEampgYFvB.1Feb9W90zN8e23vIM2zB80SWLM/h4rEUVq","expiry":1484052150}}	email	jazhang@xogrp.com	\N	1	      0    	User	80	1	\N
41	jili@xogrp.com	$2a$11$ddsH7uopM82XdlrQhxV/0uwb4XypkeFVVIBHQ2JGRLjPrEHjR/H/i	\N	\N	\N	1	2016-12-28 09:36:26.446549	2016-12-28 09:36:26.446549	172.26.0.32	172.26.0.32	2016-12-09 12:18:20.828442	2016-12-28 09:36:26.447927	Jing	Li	李静	0	2015-04-01	12	5	24	10	{"_nm-v_qWerHejGGwiBAdPA":{"token":"$2a$10$hA2nsiJnr7VnbTAzMjaXzeSfCUX.gA.RTYwnIYzK/iLDBMTKmWolW","expiry":1484098586}}	email	jili@xogrp.com	\N	1	     0   	User	83	1	\N
146	lchen@xogrp.com	$2a$11$sP/l5/YEgtySi93nO9toPOLa1q3PVgVwN0Uo8He/T3z7RC0ngS6Vm	\N	\N	\N	1	2016-12-28 10:07:19.612861	2016-12-28 10:07:19.612861	172.26.200.238	172.26.200.238	2016-12-21 16:51:58.594502	2016-12-28 10:07:19.61422	Locke	Chen	陈嘉琪	1	2016-09-26	3	1	5	26	{"TnPDK01AzqXkr4LAJo0JdQ":{"token":"$2a$10$7nSgRgHvSKK37A8cygROcOvZZCZejQeqBi.y..7PhEgW.iWGPpcne","expiry":1484100439}}	email	lchen@xogrp.com	\N	1	        0   	User	8	1	\N
87	vliang@xogrp.com	$2a$11$HBXSRR6v6cggLdi/UJOiBuw4ISYdL3IbJ0w9i0NiazlqoHJtpyL0O	\N	\N	\N	2	2016-12-28 10:15:10.362188	2016-12-23 11:46:03.768842	172.26.0.32	172.26.0.32	2016-12-09 12:18:21.147083	2016-12-28 10:15:10.364132	Vincent	Liang	梁源笙	1	2015-11-13	5	1	15	8	{"sf4ZtLouDJV9ktYlfOhJ3A":{"token":"$2a$10$ltcYBELyxTPSfAd5Dzwsf.e.E6mrddlD0GDXPmTkPU5ZAoTPIi3ve","expiry":1483674363},"QqTu_cv_y8llV45S6qT6Ew":{"token":"$2a$10$KeuhqfhjACZsjDPz/Ssgce8lGjFJeXODQxy42ZJi9hs0AC9Q3Xg8C","expiry":1484100910}}	email	vliang@xogrp.com	\N	1	08	User	8	1	\N
141	kayu@xogrp.com	$2a$11$53O.uozXL8dwRVvvh60y/u2EcDxxr7M7a2wPNqqsR8OEiFB7Eay6G	\N	\N	\N	2	2016-12-28 18:11:55.756168	2016-12-28 14:31:33.125483	172.26.0.17	172.26.0.17	2016-12-21 16:33:34.14073	2016-12-28 18:11:55.758022	Kaylor	Yu	余子凤	0	2016-11-28	3	6	20	8	{"5ymjwzc7lTF1Y0x6RT6CUQ":{"token":"$2a$10$azNYRvB8XNq3yGUPRS9/R.CMScydU2hMDcfF2Jj3INbqu/83u2wG6","expiry":1484116293},"4uHqzW4Pt2Jr08nW4JcxAw":{"token":"$2a$10$fw2ZieRo4GlYVDisFp9q8.U/oQHwC5mOWFe0pV8xFKDb2vHVeWen.","expiry":1484129515}}	email	kayu@xogrp.com	\N	1	      0       	User	111	1	\N
11	bchen@xogrp.com	$2a$11$TGFITckw49rd04E/z6X3keuFfYiGBHygaKuSQaCcWntBflCyUsAbC	\N	\N	\N	22	2016-12-23 11:46:17.373091	2016-12-22 15:43:51.522674	172.26.0.32	172.26.0.32	2016-12-09 12:18:20.598924	2016-12-29 16:13:26.019784	Ben	Chen	陈东	1	2011-07-04	10	4	11	18	{"xYr9Jalmxm734OZ58H-wuw":{"token":"$2a$10$asUSjQeSFEfJN167QTJOyuIqjSQD412/8E60.8FCdoN1stDsWg9t2","expiry":1483439122},"AbuWsBmvbYvrOQ8JO5BjMQ":{"token":"$2a$10$86WxxD2IV5WKQYWpjngUpeiiCFhpP/x/66akEJUZxqbc5oDxt1btK","expiry":1483439668},"MaypppcB6dTZt-KLADHulA":{"token":"$2a$10$ksHYyPXUm2GC2jd0Hi1p9u5/Lkf6KPqhGgT.Kl76XbunkBdzQGiWi","expiry":1483440170},"CwCagFszmxSfVEHiELpc1Q":{"token":"$2a$10$CwGkBnxObtkXIrymQoPV1uQsF2HJoRL98REuKil.ayIrtl5MgIz7y","expiry":1483602231},"FqKcjsXo87lUueDtZ77_ZA":{"token":"$2a$10$Im.vqTK8jB0EbvIkR3v82.pbXY0D77uRVG8iPDO/Dv1J.BiSNAFey","expiry":1483674377}}	email	bchen@xogrp.com	\N	1	0        	User	14	1	\N
22	dgao@xogrp.com	$2a$11$Fs7PSu9Y6IhPkUfOzElVcu72j8x1mE7c6ItdLc2yBv1hDIaxARFsu	\N	\N	\N	2	2016-12-28 12:28:31.349922	2016-12-23 11:27:37.175274	172.26.0.32	172.26.0.32	2016-12-09 12:18:20.685523	2016-12-28 12:28:31.351738	Deon	Gao	高迪安	1	2013-09-04	8	1	17	27	{"pDNfw1J3wDitKmZ67hjmaA":{"token":"$2a$10$xboHXxE2Rk1VcQXrNcIGYukGyomKoWQPdNUVTlmXUoVzS2cYZVTW6","expiry":1483673257},"KQpMmGKNhQ4YKmC6G5L3dw":{"token":"$2a$10$/fcaAP53SieKsQkp3UJIpeBG.7mvzwgyhgy0ATP4A38NZCVgQwxSe","expiry":1484108911}}	email	dgao@xogrp.com	\N	1	     0 	User	110	1	\N
78	richen@xogrp.com	$2a$11$8FMdATKp772RIZEyNic4HOzpwP4YL.gzMGMIT2dtUDT1theyCDC4O	\N	\N	\N	5	2016-12-29 14:56:58.574369	2016-12-29 11:04:30.411783	172.26.0.32	172.26.0.32	2016-12-09 12:18:21.086264	2016-12-29 14:56:58.576458	Rill	Chen	陈小溪	0	2016-03-22	2	4	31	27	{"VFbFxSial1HUa0pfFbKX5A":{"token":"$2a$10$TH3vO6WVs2fn2L6G50eOkO3DtOe4cMJNvgt/2dUCQN/.1tLxXVPdC","expiry":1483412165},"IzCXF7oa6-ccohX0SBe59g":{"token":"$2a$10$ACFmAR0ODnBLgINKQ.pjLOYpTbFgwMgrqpJG.6OUrLLlWCs/FuXAK","expiry":1483412595},"sAFrAIRXONGYBppINzrUzw":{"token":"$2a$10$QOB1V8EGC8Cn0RlER6HFhe/dQVuyTwSu4zax8rn7nxS6ah7weRBCe","expiry":1484189637},"cyJ_z74r2_0IvvD9kiaUwg":{"token":"$2a$10$mwyXFNfhoXEzE7giFDfdjuTxG2MpUqI8yoXEi6ner5JGNqlS5EEpq","expiry":1484190270},"NwSwx0XvfVREx0ZSyJ3wBA":{"token":"$2a$10$waiVa9p/3OWacGuyjPIUXe81TAOjog0uAhKrUuT5.O7c24sXRJyXa","expiry":1484204218}}	email	richen@xogrp.com	\N	1	        0        	User	14	1	\N
142	kwli@xogrp.com	$2a$11$BM45hQKI.NNcu6TnH3tPp.21zeWBY.B30N3hE0CtGOER/NxCgS1eq	\N	\N	\N	3	2016-12-30 10:15:55.720619	2016-12-29 18:07:28.739893	172.26.0.17	172.26.0.17	2016-12-21 16:41:08.485393	2016-12-30 10:15:55.722447	Kwin	Li	黎冠龙	1	2016-10-20	5	1	15	26	{"s5vEj_vucAFm_Z9K7GgbWQ":{"token":"$2a$10$vkGN/PpwTxXJhxGGtsJfpebIpvZbJ42qgOAMtA6d85978h.v4zo8u","expiry":1484107434},"koKPuhyCGEt57koG1kiVog":{"token":"$2a$10$IXKr3g2Ou6e3OoloTC3LuenSmMUldXHoQGoox/oIX6mqwKNeEWkUq","expiry":1484215648},"AGrfbULbZCE9X7uYtD_ljg":{"token":"$2a$10$j31bMzc/hVhMGrowXNXyFex/wWW1NhOsxr23o/pXZeQLlQjERICUq","expiry":1484273755}}	email	kwli@xogrp.com	\N	1	  0          	User	8	1	\N
129	davli@xogrp.com	$2a$11$oke69lbVD0784b0Nty8WcOHNjPdJ7n.y5OJkF4DinHmfpqm8AqqZi	\N	\N	\N	0	\N	\N	\N	\N	2016-12-21 15:41:06.908023	2016-12-21 15:41:47.651687	David	Li	黎永贵	1	2016-12-01	7	1	56	27	{}	email	davli@xogrp.com	\N	1	   0    	User	110	1	\N
135	henrhuang@xogrp.com	$2a$11$69IRBwBko/UQeMq.S69IIu3aWuEe6cLmERFZll6kwi31J7oLi0O2y	\N	\N	\N	2	2016-12-29 13:20:37.186368	2016-12-27 11:45:40.924883	172.26.0.17	172.26.0.17	2016-12-21 16:09:24.262405	2016-12-29 13:20:37.188	Henry	Huang	黄伟恒	1	2016-12-07	7	4	31	7	{"4DzTuZpC06M8fhN4PhvRBw":{"token":"$2a$10$TuykEhfgnjQKs2x0toJGE.VM1NfmV/Wcw47f5rCPzY5GrbTSYaMHa","expiry":1484019940},"0pSm12OLweCKzE2nG6_S0A":{"token":"$2a$10$icKh5/mGQmqXQ/jhr1J5e.S4gF1UiPyr44P5awBJTv6jo0EFNZQ1u","expiry":1484198437}}	email	henrhuang@xogrp.com	\N	1	  0        	User	14	1	\N
136	iliu@xogrp.com	$2a$11$eZgpoidZ7k0yy.QhqEGECeqfAKQIx2Gb4jdU8V7Qwsvca0mDGK1/y	\N	\N	\N	0	\N	\N	\N	\N	2016-12-21 16:11:32.84368	2016-12-21 18:04:13.79423	Ivan	Liu	刘俊杰	1	2016-11-21	8	1	38	7	{}	email	iliu@xogrp.com	\N	1	    0    	User	107	1	\N
121	ayu@xogrp.com	$2a$11$1mx3d7rzKT1KRgk0ppCUfOHY5oTvWsBzF4DoVckEhQP1Vlx1RXTii	\N	\N	\N	0	\N	\N	\N	\N	2016-12-21 14:48:12.937505	2016-12-21 14:49:07.303454	Alpha	Yu	于丛良	1	2016-10-08	12	1	54	27	{}	email	ayu@xogrp.com	\N	1	    0	User	22	1	\N
124	bou@xogrp.com	$2a$11$oGEmwuZ4lPPz8Nv4/FOACOsbt0gnFDN1thUDfOl6rELvGWemg6gRa	\N	\N	\N	0	\N	\N	\N	\N	2016-12-21 15:09:02.486118	2016-12-21 15:10:03.485557	Blair	Ou	欧海婷	0	2016-09-19	10	1	15	28	{}	email	bou@xogrp.com	\N	1	0         	User	8	1	\N
125	cou@xogrp.com	$2a$11$Rp26un6nFzyq69vN1W1Gtu0KZOm0XQXEXP8ySseiGVVIBjm5Osw8S	\N	\N	\N	0	\N	\N	\N	\N	2016-12-21 15:17:09.084717	2016-12-21 15:17:09.084717	Celine	Ou	欧思宁	0	2016-07-11	8	5	12	10	{}	email	cou@xogrp.com	\N	1	   0 	User	83	1	\N
134	fowei@xogrp.com	$2a$11$mCykvbyVANs54EdDghQ1MOy0ei/NXoFXkm8i/A40.hFoI1she6ae6	76e9a50f4cf8b7f17c74e9527718b65aa07157f59b227b0b8c8184d283f6a08e	2016-12-28 16:28:57.159973	\N	0	\N	\N	\N	\N	2016-12-21 16:02:04.844242	2016-12-28 16:28:57.164435	Forest	Wei	韦森林	1	2016-08-01	5	1	32	26	{}	email	fowei@xogrp.com	\N	1	         0  	User	8	1	\N
123	alin@xogrp.com	$2a$11$nLQmvdBMsLGJJ2Vjb0YTEOhCzaPct3k4Q6EAYhY5ZGiezSXhMwxPW	\N	\N	\N	1	2016-12-23 11:40:22.425367	2016-12-23 11:40:22.425367	172.26.0.32	172.26.0.32	2016-12-21 15:00:55.040652	2016-12-23 11:40:22.42678	Arlene	Lin	林灵芝	0	2016-11-21	11	1	46	19	{"DWQftI8-XTiaG0wkNpZ-fg":{"token":"$2a$10$AJ4uqHhD1S3myO19X9tBN.UI8P6ELeZrwsZ3DYHAX3z12TFUs3XDO","expiry":1483674022}}	email	alin@xogrp.com	\N	1	0       	User	\N	1	\N
128	ckong@xogrp.com	$2a$11$qffwPtlTqSFImskUr5YHBuAbcpjn9bj8IZn6ZzFPG6iZGKcthL8qG	\N	\N	\N	0	\N	\N	\N	\N	2016-12-21 15:28:55.980943	2016-12-21 15:28:55.980943	Crystal	Kong	孔晓彤	0	2016-08-24	5	4	31	11	{}	email	ckong@xogrp.com	\N	1	  0     	User	34	1	\N
122	apeng@xogrp.com	$2a$11$WIG4ow8dQyFfXO1AxIxv1epKEn4NpkzJ6siqcaL.H8CWzdL4CcBNy	\N	\N	\N	2	2016-12-29 17:09:28.341292	2016-12-29 17:07:18.31542	172.26.10.152	172.26.0.17	2016-12-21 14:55:16.828216	2016-12-29 17:09:28.343819	Ann	Peng	彭安秀	0	2016-07-01	8	1	15	26	{"KWrACu-HfmFJ91s0CINvtA":{"token":"$2a$10$fu270nx5JlhoZ3/0z75vF..St/8FjRtLUrHweTEjQtdTACG8vfIj.","expiry":1484212038},"iXWcvd4qYYPB8icfDqKwcg":{"token":"$2a$10$Mm8rTDndvS54sWvDh5kFQug5vwCUOojXJfr52qaerVbom035jnQSK","expiry":1484212168}}	email	apeng@xogrp.com	\N	1	      0	User	8	1	\N
132	erzhou@xogrp.com	$2a$11$P1Q14EQTxYy20pOGh8iqg.76GJnEKmmhbEwH3G0ZM5d1OXuFJ4bB6	\N	\N	\N	0	\N	\N	\N	\N	2016-12-21 15:54:50.654123	2016-12-21 15:55:52.985076	Erica	Zhou	周静妮	0	2016-11-21	11	4	58	26	{}	email	erzhou@xogrp.com	\N	1	       0   	User	14	1	\N
127	cihuang@xogrp.com	$2a$11$NJGb.OZOAntYZTe6hzIpZOUpEdOFO3sL3EmDxESY0HM43XVrI0Ala	\N	\N	\N	1	2016-12-30 09:30:03.550772	2016-12-30 09:30:03.550772	172.26.0.17	172.26.0.17	2016-12-21 15:25:03.384565	2016-12-30 09:30:03.552423	Cindy	Huang	黄芷辛	0	2016-07-04	11	6	43	26	{"AVvv7uN83GdO1lJQDYckHA":{"token":"$2a$10$4EeSm.2AxprwNpsc//6VL.bjdfBtRT7mxruIVKN5.myIC59JdL2qe","expiry":1484271003}}	email	cihuang@xogrp.com	\N	1	  0    	User	111	1	\N
120	alwu@xogrp.com	$2a$11$0q1AZ8kueKGXbFGo6JxjBer.PvNHRX6e3RzXEsca8HQS/MJUVHlmu	\N	\N	\N	3	2016-12-30 14:06:49.678964	2016-12-28 10:16:45.748551	172.26.0.32	172.26.0.32	2016-12-21 14:41:58.611787	2016-12-30 14:06:49.680943	Allan	Wu	吴成龙	1	2016-12-07	6	4	14	9	{"qPyrlkIn6fw69ztjhGxyCg":{"token":"$2a$10$b078dw1vsv.qG1NcVJRxzuUpaFRa25vcTMmXk68SnQa88Azlesw1.","expiry":1484100487},"_Fpl9S3w-TAMpAImYmkv1w":{"token":"$2a$10$RFjVoSmPm.0gZkNl5r6I.er51QIB3i4Hl21AhmpVuvwgwNlUl6M56","expiry":1484101005},"9TPMsmBfaaza6dsLQRHoPQ":{"token":"$2a$10$EsBOu8Fz7i8WbCdUzebU9OFYSGKqIBlgszfp8xLZ9zPlvOAj5iSnq","expiry":1484287609}}	email	alwu@xogrp.com	\N	1	  0 	User	14	1	\N
40	jerli@xogrp.com	$2a$11$siSW9yvExV2X90LfeaoI5eFi18oMH2ys6iwXR5VaZpoubDrxWFUzy	\N	\N	\N	1	2016-12-20 19:27:21.898684	2016-12-20 19:27:21.898684	172.26.0.17	172.26.0.17	2016-12-09 12:18:20.821388	2016-12-21 16:22:32.757004	Jerry	Li	李杰荣	1	2014-12-24	9	1	3	27	{"cdGbVW0FREcJXof-ZCzVcA":{"token":"$2a$10$OSaHKf.KSz1lsWozSjE0Oegepw7GpZDj6gTzW8/3F1buv/SXCAhhS","expiry":1483442841}}	email	jerli@xogrp.com	\N	1	      0     	User	22	1	\N
140	jzhang@xogrp.com	$2a$11$HIcYQoQuEVOjN8Wt5bKiguA7eDI88rBJRHOGOE6MIiFxM/3fwnMPu	\N	\N	\N	0	\N	\N	\N	\N	2016-12-21 16:26:21.431388	2016-12-21 16:26:21.431388	Johnny	Zhang	张明杰	1	2016-08-23	9	1	15	8	{}	email	jzhang@xogrp.com	\N	1	    0     	User	8	1	\N
83	sliao@xogrp.com	$2a$11$lx3c3eMHxxnGZH.7b332qO8B84b7r72tYqDZ2yg5YbpsPCkGmL8MO	\N	\N	\N	1	2016-12-23 12:37:52.814758	2016-12-23 12:37:52.814758	172.26.0.32	172.26.0.32	2016-12-09 12:18:21.120041	2016-12-23 12:37:52.818171	Sasha	Liao	廖琰	0	2013-03-01	10	5	62	10	{"NA2Y7ih75G2NTCIcmgKcXQ":{"token":"$2a$10$vVSdUNQepKx/nOdCDtMqCOtM9vWlFMUqq/a2/e9I0b83zag4FE0WK","expiry":1483677472}}	email	sliao@xogrp.com	\N	1	        0         	User	109	1	\N
39	jecai@xogrp.com	$2a$11$D.ixCk86mQDwuwzoG5iCRuIZl.4JGk3bPRxXiZArPlzUlsqvRx45u	\N	\N	\N	1	2016-12-23 17:08:38.480157	2016-12-23 17:08:38.480157	172.26.0.32	172.26.0.32	2016-12-09 12:18:20.814459	2016-12-23 17:08:38.481603	Jelly	Cai	蔡静思	0	2016-03-24	7	5	30	16	{"eSk6mBzsnLiuZQLKJ39WIw":{"token":"$2a$10$w0W6mL0mQ0Zya76Ins8EcuU3regCBJxmEQnMG2sIyw7vnL.WfZFCO","expiry":1483693718}}	email	jecai@xogrp.com	\N	1	0           	User	63	1	\N
26	fichen@xogrp.com	$2a$11$r1/1vXLxBdG.pMEXL4z2OOrdl3YPNF9bQj6DSFeaD8nDFloG9o57K	\N	\N	\N	1	2016-12-23 16:54:35.869226	2016-12-23 16:54:35.869226	172.26.0.32	172.26.0.32	2016-12-09 12:18:20.72747	2016-12-23 16:54:35.870628	Fiona	Chen	陈海媚	0	2016-03-22	9	5	30	16	{"fz5YsKAjRjrhNIw6hWJuDg":{"token":"$2a$10$YzJMrNKXTsCfhAQTL5gcz.1EtPsJqSeuh2I9LbiFIvHrWFxURui5W","expiry":1483692875}}	email	fichen@xogrp.com	\N	1	         0 	User	63	1	\N
133	esqiu@xogrp.com	$2a$11$RBU1/oe4EzAGp8WLkB.TTuQV7eW3O1/fMEUpjvYH3s6qlvYBg8/Au	107c519e13eb4aa316a6837bb68bcb868de958b20e378abda331d3dfd4b612bc	2016-12-23 22:21:05.985438	\N	0	\N	\N	\N	\N	2016-12-21 15:58:16.301375	2016-12-23 22:21:05.989741	Estelle	Qiu	丘华星	0	2016-07-11	7	1	38	8	{}	email	esqiu@xogrp.com	\N	1	       0    	User	8	1	\N
119	agong@xogrp.com	$2a$11$xRJPwarnN8tU.d6RQpdcbubYNwtosfP8DSpgc1vIJjwy9bLTe.y6u	\N	\N	\N	1	2016-12-27 12:39:23.572002	2016-12-27 12:39:23.572002	172.26.9.152	172.26.9.152	2016-12-21 14:30:14.307757	2016-12-27 12:39:23.573373	Aber	Gong	龚亮杰	1	2016-08-18	8	1	15	26	{"ybIfNgmjB8VV0_MsS8mOuA":{"token":"$2a$10$JsB48H7ql4Zei8pgfHQrJORrreX9eB8CVq9kSJVp4Y//jnfSXZz4K","expiry":1484023163}}	email	agong@xogrp.com	\N	1	0 	User	8	1	\N
126	chhuang@xogrp.com	$2a$11$dgTTH5S7fxG6jflwBdw.M.v1/jWk3P.qMa4a8SJDwAkjHSN4DeS0S	\N	\N	\N	1	2016-12-27 18:14:05.005295	2016-12-27 18:14:05.005295	172.26.0.32	172.26.0.32	2016-12-21 15:21:12.176675	2016-12-27 18:14:05.006711	Cherry	Huang	黄少仪	0	2016-11-10	11	1	55	7	{"JrkoLcm9fdl6bmsRpifMkg":{"token":"$2a$10$WrM70o8kBFXbhhuii0GUieYumXwtUnJXIlksxlGfHY9.ljxivaO/W","expiry":1484043244}}	email	chhuang@xogrp.com	\N	1	 0   	User	76	1	\N
2	adli@xogrp.com	$2a$11$b3uRp7Dqcakxu8dk3J.V9OXUeMA6mgU7E6jXqD9d.zSo4oxnqPpY.	\N	\N	\N	1	2016-12-23 13:40:47.358239	2016-12-23 13:40:47.358239	172.26.0.32	172.26.0.32	2016-12-09 12:18:20.526615	2016-12-23 13:40:47.359554	Adrian	Li	李其轩	1	2015-10-14	4	2	53	2	{"Rtfo28BY7ur1F7LeiiwXIw":{"token":"$2a$10$Yw9ROq5z2ee2bOQ1sd1JNu7M0DbsJHQCls1ijRMSoRFcaWObLbx4q","expiry":1483681247}}	email	adli@xogrp.com	\N	1	0  	User	48	1	\N
150	vwenwen@xogrp.com	$2a$11$NZ3rO/8vYLW071J8qn8Oc.6BaajSGEGT.N1jwY8ZYy2ze27JodgmK	\N	\N	\N	3	2016-12-27 10:36:22.90667	2016-12-23 16:29:33.740967	172.26.0.32	172.26.0.32	2016-12-21 17:55:39.925038	2016-12-27 10:36:22.908386	Vincent	Wen	温伟尚	1	2016-12-12	5	1	37	19	{"jTp2rEtCbUyvE25x0Lo6Xw":{"token":"$2a$10$9AwHGthw//wnHPUBa2fyyuC4itbLcIDFmkZAiKomsugo31N6o3cWm","expiry":1483675922},"qb7K0p0bCLqQDI8Cm1lQbw":{"token":"$2a$10$QYvpHnXdQEUZBlj18RfKU.wwQFTqO98wlTG2tyt5gZ0.9rywl11iq","expiry":1484015782}}	email	vwenwen@xogrp.com	\N	1	16	User	109	1	\N
138	jaszhang@xogrp.com	$2a$11$r0mioUhFjyHJt2xXBmskXujiUQCdM4VwkF8TKijIi67Kyp6KZP.7O	\N	\N	\N	5	2016-12-28 18:45:42.30059	2016-12-28 18:44:34.332477	172.26.0.17	172.26.0.17	2016-12-21 16:18:01.059268	2016-12-28 18:45:42.302623	Jason	Zhang	张日晖	1	2016-12-01	10	1	1	28	{"nXUQaFCxwX_9bpQoKzFwOA":{"token":"$2a$10$ZghuTknLUVwTNZ4WJdnCEeJYsphp5.3QU2acZh4V/t0MMmL2nkRyG","expiry":1483674058},"-yrymT6GHGRRE4pVlgJlLg":{"token":"$2a$10$o1yn.EtmGCdLrr6MpB0jZuoNRUlFXGX0lpCWW6NQqI.SX08bye9rS","expiry":1484012664},"4p2kpODQKlIbDK6xl-OJ9g":{"token":"$2a$10$sAV1jMaxL7B.sVmW7yGWUu3JSyIUApDWs2oH/XzJynckK3Kxb6La6","expiry":1484099006},"XZlG5jKYBPpAtOn-ng0DYg":{"token":"$2a$10$6EtvLJDPXwuq6h2LNrNBp.9R4Ejaot7jqr0WhwF9ZEpwX0EljNX/e","expiry":1484131474},"MC5IeeW0pFDpm7NoRYqY-Q":{"token":"$2a$10$jlefbCstaId/6oB1AbZPSu4iT3j3NXyW6e6Qbo21NnbDKGphfDa/a","expiry":1484131542}}	email	jaszhang@xogrp.com	\N	1	         0   	User	8	1	\N
1	aalin@xogrp.com	$2a$11$ZkRs0nKXVW33Bm82QKo7leFnN8MgC0WpFe2.Jc0pXjcXhSghjkkBS	\N	\N	\N	13	2016-12-30 14:14:23.05691	2016-12-23 12:26:28.238353	172.26.0.17	172.26.0.17	2016-12-09 12:18:20.516832	2016-12-30 14:14:23.058873	Aaron	Ling	凌剑荣	1	2015-09-24	8	1	1	1	{"NhNWQp874XxNt9bBp-9vYw":{"token":"$2a$10$Nzpkp2o1URKSliVPMfwR0.tt2mCCwlJKPKh4ihIt/D5iNLMaxMpuq","expiry":1483440317},"2dQyi9NdzRo1kDhlw_j_yQ":{"token":"$2a$10$7vC/Z3OZ.hEoVotjEFwQTO8.n55zxxDl7TM6QC8OESMIEoDYMCTwa","expiry":1483521041},"-49ng5bEzgORpp2lDw6rqg":{"token":"$2a$10$P0eHJE3JXQPibNVbrDJ56.Md4/EpNQG3oo.uOnDZMYq0pxZ3EfQFW","expiry":1483676788},"KZkibioxZSRArYxvhvjWDg":{"token":"$2a$10$ojTRkD69rQPe/hQZsKrHceT/ffEiSGFdn2y7YVaqTf8M8smNZC/2S","expiry":1484288063}}	email	aalin@xogrp.com	\N	1	 0 	Owner	\N	1	\N
131	ewu@xogrp.com	$2a$11$QA4WxytoBThooWRCcpJqauSzZB/AnFRH2EM3YBV2.apmU5IrJJgei	\N	\N	\N	5	2016-12-29 10:51:20.777263	2016-12-29 10:41:18.739084	172.26.0.32	172.26.0.32	2016-12-21 15:48:48.077143	2016-12-29 10:51:20.779392	Elena	Wu	吴秀	0	2016-07-18	2	5	57	20	{"iHw7vZYn-2hDCZP6gWauiA":{"token":"$2a$10$rJhRDB30Uq4LBfKKbzP3MOFaVvh0ZCcbCicsItu4lhTCZrQM84eHu","expiry":1483674238},"86nWvyh3oJRM1nMdvvsZ-Q":{"token":"$2a$10$jln4uA7mDrLmiLDOzeJSWeW2e.lhOgieLlSLLSsZm0BpQlNirJ5aS","expiry":1483697607},"BZP3SWwWA7h-C2_FtaijfA":{"token":"$2a$10$RYdnDD0cvITbIEicd3XzNuwx2Mv9rWWB8G2/FAYf3eZxjkxebjRA6","expiry":1484186891},"8PXq9-PoMTpl7P4HKNeK0Q":{"token":"$2a$10$31xtbF3SPEdnMhoADCnS/esebVl2drWLXs7lD/pT28.divBNDXrGO","expiry":1484188878},"z2xQIsM3B7eQOmLmqe1_7g":{"token":"$2a$10$RQ.8Ts61XClcLdzpiRn9YuTfRZ5sVRpMBGZhU2YTECaludGMtzjAG","expiry":1484189480}}	email	ewu@xogrp.com	\N	1	      0   	User	83	1	\N
130	duxiao@xogrp.com	$2a$11$mh0Rvny4oxbzQOubNFoU3.DOuDne94V13xcq9EzDk3D/PKQPyKJyS	\N	\N	\N	6	2016-12-28 23:20:27.51967	2016-12-28 22:32:32.044553	172.26.0.17	172.26.0.17	2016-12-21 15:45:39.357715	2016-12-28 23:20:27.522152	Duncan	Xiao	肖杵坤	1	2016-10-08	10	1	15	11	{"ULOl8I1UxDaM8p7UKiFVjw":{"token":"$2a$10$lHzXbm4vXbiXWxrHwKsezu4Qt9pPR2tqvFXMo9ZPT.twH4RWMNcjm","expiry":1483674306},"W-sXgZIgUT1njdmOT-tycw":{"token":"$2a$10$ovAAxSOTrRpfjI1.BTYud.viFZEgnSV.hm5oBB4wdcv0Uf4Rb9p4u","expiry":1484058558},"eFbLzEWL6l8KVHLDMn4HOw":{"token":"$2a$10$G0cVzhNyj7F6x1TWG8XCNOTfc8D2jbVhU.Ygrwr6dhAHjeYwBaABu","expiry":1484065613},"XJuglGDv8Jh8OvNJ1teFqg":{"token":"$2a$10$qK/UNRmf9/uTDxoCrPsql..PsOKMqU21gtd08UjxB5Kf72ho0QVUS","expiry":1484101445},"0ejJ4F5HOJkrWD2p2_mLMA":{"token":"$2a$10$gBzn3IVq5CkqBiLtMbPXJOugvoLHyAIU4ml2JeO.eZjoQCCS8WPr2","expiry":1484145152},"jVnFQ2oMvbWFAI7KhUtOkQ":{"token":"$2a$10$aE44iuN9QeRUqOfxDG5q7ekokMr72qLQSbS/B0jcKyOBC9qPsVbZK","expiry":1484148027}}	email	duxiao@xogrp.com	\N	1	      0 	User	80	1	\N
46	kyao@xogrp.com	$2a$11$RhP.VMF87/fWeAxb9m0mxesmRBm1dLHDZ3As1c7ZmxuYs9XQr4VCW	\N	\N	\N	3	2016-12-28 12:49:12.034084	2016-12-23 10:46:30.279687	172.26.0.32	172.26.0.32	2016-12-09 12:18:20.862172	2016-12-28 12:49:12.035886	Kammy	Yao	姚晓玲	0	2015-06-08	2	3	59	4	{"wmJ-5r__mtdB47PlviUSTA":{"token":"$2a$10$m1R.ABONFikfsHe3NcjsW.AWZuprLD3wVvjDPWyA3n0W9Xi6i0lyW","expiry":1483591273},"Y0gQIg1Fzt20MtxnoQjUMg":{"token":"$2a$10$XGjbCcIKXz9elhGcTjCBPeo6DON600whzAetnlP55iZeQoYCJ.IRK","expiry":1483670790},"ZnmNKhtcIlREgbzbCV01-g":{"token":"$2a$10$CFMkroEMaSDCTcmyuhSxQeNVITAwEFRTDOkH0/QxuHXyE7jcWSWL.","expiry":1484110152}}	email	kyao@xogrp.com	\N	1	   0         	Admin	68	1	\N
109	wdeng@xogrp.com	$2a$11$GWNmVtAOLRxscVp9nc/t3eqFCKraYfFG7DGnZ1Exn8yOGEaVtf0ei	\N	\N	\N	8	2016-12-29 12:17:07.407598	2016-12-22 15:48:31.97235	172.26.0.17	172.26.0.32	2016-12-09 12:18:21.296258	2016-12-29 12:17:07.409629	Wendy	Deng	Wendy Deng	0	2009-05-01	8	8	63	25	{"J4sg4PkcAj8kQwemObS9oQ":{"token":"$2a$10$rFuJ.BbgnqeQQXVwD9DjF.JuHWWKZxaK.ONWlxbHFBvzivpscqHte","expiry":1483338922},"DiEmEsTPoUSK0OCmwF_6Rg":{"token":"$2a$10$gF5XlLP4WLQggovkYibHI.C9gROuK3uHTAeNf7u./6VU85dPNV5BS","expiry":1483413396},"qdWE9Aw_18enEY0A1ghLGQ":{"token":"$2a$10$v40H4ah8tCkfZzP8cuzfE.kcnYqGUuuF7sYmVwK5WzmRr5yzL6OEi","expiry":1483601585},"bCy6Dz2qph8USINgKbfCgw":{"token":"$2a$10$q7nJGUqxPgCKsxZy9hjYausG1sTEu2obpRBkN2ExMVEV5yxyeRuRi","expiry":1483602511},"ZUavCK7QjQoxn0s9reJKTA":{"token":"$2a$10$YbRTIjsi4hZDFQ87HqxLp.F9B66Xmu.5u38cNx.bZeuoQ8pSd6y12","expiry":1484194627}}	email	wdeng@xogrp.com	\N	1	18	Admin	112	1	\N
101	vma@xogrp.com	$2a$11$qP1NCg4NWnri1D/oTfOWR.69gcfU23/t6XW5GXwddZ8uswrQrdYDC	\N	\N	\N	6	2016-12-29 17:23:07.161868	2016-12-29 16:57:42.131211	172.26.0.17	172.26.0.17	2016-12-09 12:18:21.24235	2016-12-29 17:23:07.163769	Vincy	Ma	马少敏	0	2015-03-30	12	5	35	10	{"IFppBQijbJOGhgVB31aGxA":{"token":"$2a$10$izrmFyD2xhHX713PoZNTt.HUzLOUpeLLi94CJMJ2NbXsb2KvUuGG.","expiry":1483674470},"MV1ZmlrioyEAOIAxpKUXEQ":{"token":"$2a$10$gwd9q5eMp1hkXGPmwU.SoO8GEdqohFOqeIhb2if7sDMngSUcqjfVK","expiry":1484101927},"xD9whCYqJyh41k4snwmPRQ":{"token":"$2a$10$ApdazrVAVmeAH5EYZYwsOu.5dZNXgzrSupjoEpq9E6vjVQ4CxXH/y","expiry":1484102023},"KYXgz5jmpUR1RTNn0yXAuw":{"token":"$2a$10$VNn9zUhZRIN0A4Jr9099oeRXEqJ60dAFuIDNoLoocULtCdIFoN5eW","expiry":1484122976},"9zShDdiuQjyCMO-eTEI1UA":{"token":"$2a$10$dopxcCoDLssXentYTZDyyOxLJjoDNleK0x.mphQ98a7.JWvdRDK4u","expiry":1484211462},"JIO8PGVHI7JGBMsJNVWqTA":{"token":"$2a$10$EjphpgTnVvfMzm9KdtzGQ.YW1YQm9n6hcsq.8GLMcljcWmxPi7l0y","expiry":1484212987}}	email	vma@xogrp.com	\N	1	17	User	83	1	\N
35	jacai@xogrp.com	$2a$11$XPHuF7.XweH9YE6lUS7OgOFHhQdo26tBH7.wdPbEtn54Or/0GxBgi	\N	\N	\N	4	2016-12-29 15:43:00.67861	2016-12-29 15:41:57.156446	172.26.0.17	172.26.0.17	2016-12-09 12:18:20.787743	2016-12-29 15:43:00.680475	Jace	Cai	蔡月霞	0	2016-04-11	10	6	22	27	{"06JL6fo0jHf23yWILmCocA":{"token":"$2a$10$BsOWoAK5EaAnoXwSRCBTful5S9KRhQvaoU/RLQ.a.uQme3hI1CaMS","expiry":1483673634},"QLEihUshWLTe2ZAUtATu2g":{"token":"$2a$10$VEo/.GrGb9P7w2ClHjZANuNq.aNzGoHg.CMH.N86WYWhxyCrLBofO","expiry":1484192735},"WoEJ7KrU3uU4TCZIE0TJIg":{"token":"$2a$10$OekLpjv0.daFbATY2qmJZ.I4sHHfyMs6KsRjvoGNnOa9C5geQ5x4q","expiry":1484206917},"OV5xWaIDfpdq_f06chdaoA":{"token":"$2a$10$IJKkjgGFq9TbOdEBWVxnxewhydPdQlpbzEN0UEB4epjWl0EDyd3EO","expiry":1484206980}}	email	jacai@xogrp.com	\N	1	     0  	User	111	1	\N
100	vhe@xogrp.com	$2a$11$JxDVrxAqx4oEMl9gv02bfePUak9sZhPgGuliSRY/2fGQcIiTYlmV2	\N	\N	\N	3	2017-01-06 17:50:02.507936	2017-01-06 17:23:18.135481	::1	::1	2016-12-09 12:18:21.235695	2017-01-06 17:50:02.509884	Vince	He	何文斯	1	2016-05-04	1	1	45	29	{"nHHPxUWQRWe7EJl85DSf3w":{"token":"$2a$10$ZupgsIiUK8CqGXH3HvrcF.Rr4V3aQXjsHo8HE0/zHcPKCiOkd6dqe","expiry":1483065466}}	email	vhe@xogrp.com	\N	1	07	User	110	1	\N
\.


--
-- TOC entry 2564 (class 0 OID 0)
-- Dependencies: 194
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_id_seq', 151, true);


--
-- TOC entry 2378 (class 2606 OID 16495)
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- TOC entry 2388 (class 2606 OID 16551)
-- Name: ckeditor_assets ckeditor_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY ckeditor_assets
    ADD CONSTRAINT ckeditor_assets_pkey PRIMARY KEY (id);


--
-- TOC entry 2391 (class 2606 OID 16560)
-- Name: departments_events departments_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY departments_events
    ADD CONSTRAINT departments_events_pkey PRIMARY KEY (id);


--
-- TOC entry 2357 (class 2606 OID 16442)
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- TOC entry 2360 (class 2606 OID 16444)
-- Name: employment_types employment_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY employment_types
    ADD CONSTRAINT employment_types_pkey PRIMARY KEY (id);


--
-- TOC entry 2384 (class 2606 OID 16528)
-- Name: enrollments enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY enrollments
    ADD CONSTRAINT enrollments_pkey PRIMARY KEY (id);


--
-- TOC entry 2380 (class 2606 OID 16509)
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- TOC entry 2362 (class 2606 OID 16446)
-- Name: job_titles job_titles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY job_titles
    ADD CONSTRAINT job_titles_pkey PRIMARY KEY (id);


--
-- TOC entry 2376 (class 2606 OID 16487)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 2365 (class 2606 OID 16448)
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- TOC entry 2374 (class 2606 OID 16450)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 2389 (class 1259 OID 16552)
-- Name: index_ckeditor_assets_on_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ckeditor_assets_on_type ON ckeditor_assets USING btree (type);


--
-- TOC entry 2392 (class 1259 OID 16571)
-- Name: index_departments_events_on_department_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_departments_events_on_department_id ON departments_events USING btree (department_id);


--
-- TOC entry 2393 (class 1259 OID 16572)
-- Name: index_departments_events_on_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_departments_events_on_event_id ON departments_events USING btree (event_id);


--
-- TOC entry 2358 (class 1259 OID 16451)
-- Name: index_departments_on_manager_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_departments_on_manager_id ON departments USING btree (manager_id);


--
-- TOC entry 2385 (class 1259 OID 16539)
-- Name: index_enrollments_on_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_enrollments_on_event_id ON enrollments USING btree (event_id);


--
-- TOC entry 2386 (class 1259 OID 16540)
-- Name: index_enrollments_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_enrollments_on_user_id ON enrollments USING btree (user_id);


--
-- TOC entry 2381 (class 1259 OID 16515)
-- Name: index_events_on_event_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_events_on_event_type ON events USING btree (event_type);


--
-- TOC entry 2382 (class 1259 OID 16516)
-- Name: index_events_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_events_on_user_id ON events USING btree (user_id);


--
-- TOC entry 2363 (class 1259 OID 16452)
-- Name: index_teams_on_leader_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_teams_on_leader_id ON teams USING btree (leader_id);


--
-- TOC entry 2366 (class 1259 OID 16453)
-- Name: index_users_on_department_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_department_id ON users USING btree (department_id);


--
-- TOC entry 2367 (class 1259 OID 16454)
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_email ON users USING btree (email);


--
-- TOC entry 2368 (class 1259 OID 16455)
-- Name: index_users_on_employment_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_employment_type_id ON users USING btree (employment_type_id);


--
-- TOC entry 2369 (class 1259 OID 16456)
-- Name: index_users_on_job_title_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_job_title_id ON users USING btree (job_title_id);


--
-- TOC entry 2370 (class 1259 OID 16457)
-- Name: index_users_on_manager_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_manager_id ON users USING btree (manager_id);


--
-- TOC entry 2371 (class 1259 OID 16458)
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON users USING btree (reset_password_token);


--
-- TOC entry 2372 (class 1259 OID 16459)
-- Name: index_users_on_team_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_team_id ON users USING btree (team_id);


--
-- TOC entry 2398 (class 2606 OID 16510)
-- Name: events fk_rails_0cb5590091; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY events
    ADD CONSTRAINT fk_rails_0cb5590091 FOREIGN KEY (user_id) REFERENCES users(id);


--
-- TOC entry 2401 (class 2606 OID 16561)
-- Name: departments_events fk_rails_1fde746960; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY departments_events
    ADD CONSTRAINT fk_rails_1fde746960 FOREIGN KEY (department_id) REFERENCES departments(id);


--
-- TOC entry 2402 (class 2606 OID 16566)
-- Name: departments_events fk_rails_a52209262f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY departments_events
    ADD CONSTRAINT fk_rails_a52209262f FOREIGN KEY (event_id) REFERENCES events(id);


--
-- TOC entry 2399 (class 2606 OID 16529)
-- Name: enrollments fk_rails_a6378ee767; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY enrollments
    ADD CONSTRAINT fk_rails_a6378ee767 FOREIGN KEY (event_id) REFERENCES events(id);


--
-- TOC entry 2394 (class 2606 OID 16460)
-- Name: users fk_rails_b2bbf87303; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users
    ADD CONSTRAINT fk_rails_b2bbf87303 FOREIGN KEY (team_id) REFERENCES teams(id);


--
-- TOC entry 2395 (class 2606 OID 16465)
-- Name: users fk_rails_b590639e90; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users
    ADD CONSTRAINT fk_rails_b590639e90 FOREIGN KEY (job_title_id) REFERENCES job_titles(id);


--
-- TOC entry 2396 (class 2606 OID 16470)
-- Name: users fk_rails_d1c86232a5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users
    ADD CONSTRAINT fk_rails_d1c86232a5 FOREIGN KEY (employment_type_id) REFERENCES employment_types(id);


--
-- TOC entry 2400 (class 2606 OID 16534)
-- Name: enrollments fk_rails_e860e0e46b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY enrollments
    ADD CONSTRAINT fk_rails_e860e0e46b FOREIGN KEY (user_id) REFERENCES users(id);


--
-- TOC entry 2397 (class 2606 OID 16475)
-- Name: users fk_rails_f29bf9cdf2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users
    ADD CONSTRAINT fk_rails_f29bf9cdf2 FOREIGN KEY (department_id) REFERENCES departments(id);


-- Completed on 2017-01-09 08:01:43 CST

--
-- PostgreSQL database dump complete
--

